package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = TerracottaPrimary,
    onPrimary = Color.White,
    primaryContainer = TerracottaContainer,
    onPrimaryContainer = OnTerracottaContainer,
    secondary = SageSecondary,
    onSecondary = Color.White,
    secondaryContainer = SageContainer,
    onSecondaryContainer = OnSageContainer,
    tertiary = OchreTertiary,
    onTertiary = Color.White,
    tertiaryContainer = OchreContainer,
    background = PaperCream,
    onBackground = CharcoalInk,
    surface = PaperCard,
    onSurface = CharcoalInk,
    surfaceVariant = PaperSurfaceVariant,
    onSurfaceVariant = WarmGraphite,
    outline = PaperOutline,
    outlineVariant = CanvasBorderLight,
    error = ErrorRed,
    errorContainer = ErrorContainerLight
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkTerracotta,
    onPrimary = Color(0xFF3A1204),
    primaryContainer = DarkTerracottaContainer,
    onPrimaryContainer = Color(0xFFFFDBD0),
    secondary = DarkSage,
    onSecondary = Color(0xFF0E2B1A),
    secondaryContainer = DarkSageContainer,
    onSecondaryContainer = Color(0xFFD5EEDD),
    tertiary = OchreContainer,
    background = DarkStudioBg,
    onBackground = DarkStudioText,
    surface = DarkStudioSurface,
    onSurface = DarkStudioText,
    surfaceVariant = DarkStudioSurfaceVariant,
    onSurfaceVariant = DarkStudioSubtext,
    outline = DarkStudioOutline,
    outlineVariant = Color(0xFF36322E)
)

private val DrawStepShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun DrawStepTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = DrawStepTypography,
        shapes = DrawStepShapes,
        content = content
    )
}
