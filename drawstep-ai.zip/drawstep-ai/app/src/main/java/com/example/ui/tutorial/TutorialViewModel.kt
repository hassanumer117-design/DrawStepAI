package com.example.ui.tutorial

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.DrawingRepository
import com.example.domain.model.DrawingTutorial
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface TutorialUiState {
    data object Loading : TutorialUiState
    data object NotFound : TutorialUiState
    data class Ready(val tutorial: DrawingTutorial) : TutorialUiState
}

class TutorialViewModel(
    private val drawingId: String,
    private val repository: DrawingRepository
) : ViewModel() {

    private val optimisticStepIndex = MutableStateFlow<Int?>(null)

    val uiState: StateFlow<TutorialUiState> = combine(
        repository.observeTutorial(drawingId),
        optimisticStepIndex
    ) { tutorial, overrideStep ->
        if (tutorial == null) {
            TutorialUiState.NotFound
        } else {
            val step = (overrideStep ?: tutorial.currentStepIndex)
                .coerceIn(0, (tutorial.totalSteps - 1).coerceAtLeast(0))
            val completed = tutorial.isCompleted || (tutorial.totalSteps > 0 && step >= tutorial.totalSteps - 1)
            TutorialUiState.Ready(
                tutorial.copy(
                    currentStepIndex = step,
                    isCompleted = completed
                )
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TutorialUiState.Loading
    )

    fun goToPreviousStep() {
        val current = (uiState.value as? TutorialUiState.Ready)?.tutorial ?: return
        if (current.currentStepIndex > 0) {
            val targetStep = current.currentStepIndex - 1
            optimisticStepIndex.value = targetStep
            viewModelScope.launch {
                repository.updateStepProgress(
                    id = current.id,
                    stepIndex = targetStep,
                    totalSteps = current.totalSteps
                )
            }
        }
    }

    fun goToNextStep(onCompletedExit: () -> Unit) {
        val current = (uiState.value as? TutorialUiState.Ready)?.tutorial ?: return
        if (current.currentStepIndex < current.totalSteps - 1) {
            val targetStep = current.currentStepIndex + 1
            optimisticStepIndex.value = targetStep
            viewModelScope.launch {
                repository.updateStepProgress(
                    id = current.id,
                    stepIndex = targetStep,
                    totalSteps = current.totalSteps
                )
            }
        } else {
            optimisticStepIndex.value = current.totalSteps - 1
            viewModelScope.launch {
                repository.updateStepProgress(
                    id = current.id,
                    stepIndex = current.totalSteps - 1,
                    totalSteps = current.totalSteps
                )
            }
            onCompletedExit()
        }
    }

    class Factory(
        private val drawingId: String,
        private val repository: DrawingRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return TutorialViewModel(drawingId, repository) as T
        }
    }
}
