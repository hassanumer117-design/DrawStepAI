package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm Atelier Paper & Charcoal Palette
val PaperCream = Color(0xFFFAF7F2)
val PaperCard = Color(0xFFFFFFFF)
val PaperSurfaceVariant = Color(0xFFF1EBE1)
val PaperOutline = Color(0xFFDAD2C5)

val CharcoalInk = Color(0xFF1F1D1B)
val WarmGraphite = Color(0xFF5C564F)
val SubtleGraphite = Color(0xFF8C847A)

val TerracottaPrimary = Color(0xFFC85A32)
val TerracottaContainer = Color(0xFFFCE4D8)
val OnTerracottaContainer = Color(0xFF541C08)

val SageSecondary = Color(0xFF4F6D5A)
val SageContainer = Color(0xFFDCEAE1)
val OnSageContainer = Color(0xFF163020)

val OchreTertiary = Color(0xFFB37B24)
val OchreContainer = Color(0xFFF9EBD2)

// Dark Studio Theme Colors (Canvas itself always stays crisp white paper)
val DarkStudioBg = Color(0xFF161514)
val DarkStudioSurface = Color(0xFF211F1D)
val DarkStudioSurfaceVariant = Color(0xFF2D2A27)
val DarkStudioOutline = Color(0xFF46413C)
val DarkStudioText = Color(0xFFF3EFEA)
val DarkStudioSubtext = Color(0xFFB7AFA6)

val DarkTerracotta = Color(0xFFEA845E)
val DarkTerracottaContainer = Color(0xFF5D2612)
val DarkSage = Color(0xFF8EC2A0)
val DarkSageContainer = Color(0xFF254231)

// Semantic Drawing Canvas Colors (Pure White Paper)
val CanvasPaperWhite = Color(0xFFFFFFFF)
val CanvasBorderLight = Color(0xFFE4DDD2)
val ErrorRed = Color(0xFFBA1A1A)
val ErrorContainerLight = Color(0xFFFFDAD6)
