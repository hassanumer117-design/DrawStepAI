package com.example.engine

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

data class PixelBuffer(
    val width: Int,
    val height: Int,
    val argb: IntArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is PixelBuffer) return false
        return width == other.width && height == other.height && argb.contentEquals(other.argb)
    }

    override fun hashCode(): Int {
        var result = width
        result = 31 * result + height
        result = 31 * result + argb.contentHashCode()
        return result
    }
}

data class SobelResult(
    val gx: FloatArray,
    val gy: FloatArray,
    val mag: FloatArray
)

object ImageProcessingUtils {

    fun downsamplePixelBuffer(src: PixelBuffer, maxDim: Int = 340): PixelBuffer {
        val w = src.width
        val h = src.height
        if (w <= 0 || h <= 0) return src
        val longest = max(w, h)
        if (longest <= maxDim) return src

        val scale = maxDim.toFloat() / longest.toFloat()
        val dstW = max(16, (w * scale).roundToInt())
        val dstH = max(16, (h * scale).roundToInt())
        val dst = IntArray(dstW * dstH)

        val xRatio = w.toFloat() / dstW.toFloat()
        val yRatio = h.toFloat() / dstH.toFloat()

        for (dy in 0 until dstH) {
            val syF = (dy + 0.5f) * yRatio - 0.5f
            val y0 = floor(syF).toInt().coerceIn(0, h - 1)
            val y1 = min(h - 1, y0 + 1)
            val wy = (syF - y0).coerceIn(0f, 1f)

            for (dx in 0 until dstW) {
                val sxF = (dx + 0.5f) * xRatio - 0.5f
                val x0 = floor(sxF).toInt().coerceIn(0, w - 1)
                val x1 = min(w - 1, x0 + 1)
                val wx = (sxF - x0).coerceIn(0f, 1f)

                val p00 = src.argb[y0 * w + x0]
                val p10 = src.argb[y0 * w + x1]
                val p01 = src.argb[y1 * w + x0]
                val p11 = src.argb[y1 * w + x1]

                val r = bilerp(
                    (p00 shr 16) and 0xFF, (p10 shr 16) and 0xFF,
                    (p01 shr 16) and 0xFF, (p11 shr 16) and 0xFF,
                    wx, wy
                )
                val g = bilerp(
                    (p00 shr 8) and 0xFF, (p10 shr 8) and 0xFF,
                    (p01 shr 8) and 0xFF, (p11 shr 8) and 0xFF,
                    wx, wy
                )
                val b = bilerp(
                    p00 and 0xFF, p10 and 0xFF,
                    p01 and 0xFF, p11 and 0xFF,
                    wx, wy
                )
                dst[dy * dstW + dx] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        return PixelBuffer(dstW, dstH, dst)
    }

    private fun bilerp(c00: Int, c10: Int, c01: Int, c11: Int, wx: Float, wy: Float): Int {
        val top = c00 + (c10 - c00) * wx
        val bot = c01 + (c11 - c01) * wx
        return (top + (bot - top) * wy).roundToInt().coerceIn(0, 255)
    }

    fun extractLuminance(buffer: PixelBuffer): FloatArray {
        val lum = FloatArray(buffer.width * buffer.height)
        for (i in lum.indices) {
            val c = buffer.argb[i]
            val a = ((c ushr 24) and 0xFF) / 255f
            val r = ((c shr 16) and 0xFF) * a + 255f * (1f - a)
            val g = ((c shr 8) and 0xFF) * a + 255f * (1f - a)
            val b = (c and 0xFF) * a + 255f * (1f - a)
            lum[i] = 0.299f * r + 0.587f * g + 0.114f * b
        }
        return lum
    }

    fun contrastStretch(lum: FloatArray): FloatArray {
        if (lum.isEmpty()) return lum
        val hist = IntArray(256)
        for (v in lum) {
            hist[v.roundToInt().coerceIn(0, 255)]++
        }
        val total = lum.size
        val lowTarget = (total * 0.02f).toInt()
        val highTarget = (total * 0.98f).toInt()

        var acc = 0
        var lowVal = 0
        for (i in 0..255) {
            acc += hist[i]
            if (acc >= lowTarget) {
                lowVal = i
                break
            }
        }
        acc = 0
        var highVal = 255
        for (i in 0..255) {
            acc += hist[i]
            if (acc >= highTarget) {
                highVal = i
                break
            }
        }
        val span = (highVal - lowVal).toFloat()
        if (span < 12f) return lum.copyOf()

        val out = FloatArray(lum.size)
        for (i in lum.indices) {
            out[i] = ((lum[i] - lowVal) / span * 255f).coerceIn(0f, 255f)
        }
        return out
    }

    fun gaussianBlur(src: FloatArray, w: Int, h: Int, sigma: Float): FloatArray {
        if (sigma <= 0.1f) return src.copyOf()
        val radius = max(1, ceil(sigma * 2.5f).toInt())
        val kernelSize = radius * 2 + 1
        val kernel = FloatArray(kernelSize)
        var sum = 0f
        val twoSigmaSq = 2f * sigma * sigma
        for (k in -radius..radius) {
            val v = exp(-(k * k) / twoSigmaSq)
            kernel[k + radius] = v
            sum += v
        }
        for (i in kernel.indices) kernel[i] /= sum

        val temp = FloatArray(w * h)
        for (y in 0 until h) {
            val rowOffset = y * w
            for (x in 0 until w) {
                var acc = 0f
                for (k in -radius..radius) {
                    val sx = (x + k).coerceIn(0, w - 1)
                    acc += src[rowOffset + sx] * kernel[k + radius]
                }
                temp[rowOffset + x] = acc
            }
        }

        val out = FloatArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                var acc = 0f
                for (k in -radius..radius) {
                    val sy = (y + k).coerceIn(0, h - 1)
                    acc += temp[sy * w + x] * kernel[k + radius]
                }
                out[y * w + x] = acc
            }
        }
        return out
    }

    fun computeSobel(lum: FloatArray, w: Int, h: Int): SobelResult {
        val gx = FloatArray(w * h)
        val gy = FloatArray(w * h)
        val mag = FloatArray(w * h)

        for (y in 1 until h - 1) {
            val ym = (y - 1) * w
            val yc = y * w
            val yp = (y + 1) * w
            for (x in 1 until w - 1) {
                val p00 = lum[ym + x - 1]
                val p01 = lum[ym + x]
                val p02 = lum[ym + x + 1]
                val p10 = lum[yc + x - 1]
                val p12 = lum[yc + x + 1]
                val p20 = lum[yp + x - 1]
                val p21 = lum[yp + x]
                val p22 = lum[yp + x + 1]

                val dx = (-p00 + p02 - 2f * p10 + 2f * p12 - p20 + p22) * 0.25f
                val dy = (-p00 - 2f * p01 - p02 + p20 + 2f * p21 + p22) * 0.25f
                val idx = yc + x
                gx[idx] = dx
                gy[idx] = dy
                mag[idx] = hypot(dx, dy)
            }
        }
        return SobelResult(gx, gy, mag)
    }

    fun cannyEdges(
        lum: FloatArray,
        w: Int,
        h: Int,
        sigma: Float,
        lowRatio: Float,
        highPercentile: Float
    ): BooleanArray {
        val smoothed = gaussianBlur(lum, w, h, sigma)
        val sobel = computeSobel(smoothed, w, h)
        val nms = FloatArray(w * h)
        val nonZeroMags = ArrayList<Float>(w * h / 4)

        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val idx = y * w + x
                val m = sobel.mag[idx]
                if (m < 2.5f) continue

                var angle = atan2(sobel.gy[idx], sobel.gx[idx]) * (180.0 / PI)
                if (angle < 0) angle += 180.0

                val (n1, n2) = when {
                    angle < 22.5 || angle >= 157.5 ->
                        sobel.mag[idx - 1] to sobel.mag[idx + 1]
                    angle < 67.5 ->
                        sobel.mag[(y - 1) * w + (x + 1)] to sobel.mag[(y + 1) * w + (x - 1)]
                    angle < 112.5 ->
                        sobel.mag[(y - 1) * w + x] to sobel.mag[(y + 1) * w + x]
                    else ->
                        sobel.mag[(y - 1) * w + (x - 1)] to sobel.mag[(y + 1) * w + (x + 1)]
                }

                if (m >= n1 && m >= n2) {
                    nms[idx] = m
                    nonZeroMags.add(m)
                }
            }
        }

        if (nonZeroMags.isEmpty()) return BooleanArray(w * h)
        nonZeroMags.sort()
        val pIdx = ((nonZeroMags.size - 1) * highPercentile).roundToInt().coerceIn(0, nonZeroMags.lastIndex)
        val highThresh = max(10f, nonZeroMags[pIdx])
        val lowThresh = max(4.5f, highThresh * lowRatio)

        val edges = BooleanArray(w * h)
        val queue = IntArray(w * h)
        var head = 0
        var tail = 0

        for (i in nms.indices) {
            if (nms[i] >= highThresh) {
                edges[i] = true
                queue[tail++] = i
            }
        }

        while (head < tail) {
            val idx = queue[head++]
            val cx = idx % w
            val cy = idx / w
            for (dy in -1..1) {
                val ny = cy + dy
                if (ny !in 1 until h - 1) continue
                for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val nx = cx + dx
                    if (nx !in 1 until w - 1) continue
                    val nIdx = ny * w + nx
                    if (!edges[nIdx] && nms[nIdx] >= lowThresh) {
                        edges[nIdx] = true
                        queue[tail++] = nIdx
                    }
                }
            }
        }

        return edges
    }

    fun computeSaliencyMask(
        buffer: PixelBuffer,
        lum: FloatArray,
        sobelMag: FloatArray
    ): BooleanArray {
        val w = buffer.width
        val h = buffer.height
        val borderMarginX = max(2, (w * 0.06f).roundToInt())
        val borderMarginY = max(2, (h * 0.06f).roundToInt())

        var sumR = 0.0
        var sumG = 0.0
        var sumB = 0.0
        var count = 0

        for (y in 0 until h) {
            for (x in 0 until w) {
                if (x < borderMarginX || x >= w - borderMarginX ||
                    y < borderMarginY || y >= h - borderMarginY
                ) {
                    val c = buffer.argb[y * w + x]
                    val a = ((c ushr 24) and 0xFF) / 255f
                    sumR += ((c shr 16) and 0xFF) * a + 255f * (1f - a)
                    sumG += ((c shr 8) and 0xFF) * a + 255f * (1f - a)
                    sumB += (c and 0xFF) * a + 255f * (1f - a)
                    count++
                }
            }
        }
        val bgR = (sumR / max(1, count)).toFloat()
        val bgG = (sumG / max(1, count)).toFloat()
        val bgB = (sumB / max(1, count)).toFloat()

        val blurredEdges = gaussianBlur(sobelMag, w, h, sigma = 4.0f)
        var maxEdge = 1f
        for (e in blurredEdges) if (e > maxEdge) maxEdge = e

        val score = FloatArray(w * h)
        val cx = w * 0.5f
        val cy = h * 0.5f
        val maxDist = hypot(cx, cy).coerceAtLeast(1f)

        for (y in 0 until h) {
            for (x in 0 until w) {
                val idx = y * w + x
                val c = buffer.argb[idx]
                val a = ((c ushr 24) and 0xFF) / 255f
                val r = ((c shr 16) and 0xFF) * a + 255f * (1f - a)
                val g = ((c shr 8) and 0xFF) * a + 255f * (1f - a)
                val b = (c and 0xFF) * a + 255f * (1f - a)

                val colorDist = hypot(r - bgR, hypot(g - bgG, b - bgB)) / 441.67f
                val edgeEnergy = (blurredEdges[idx] / maxEdge).coerceIn(0f, 1f)
                val centerBias = 1f - (hypot(x - cx, y - cy) / maxDist).coerceIn(0f, 1f)

                val lumContrast = abs(lum[idx] - (0.299f * bgR + 0.587f * bgG + 0.114f * bgB)) / 255f
                score[idx] = (0.45f * colorDist + 0.15f * lumContrast + 0.28f * edgeEnergy + 0.12f * centerBias)
                    .coerceIn(0f, 1f) * 255f
            }
        }

        val threshold = otsuThreshold(score)
        val rawMask = BooleanArray(w * h) { score[it] >= threshold }
        val dilated = morphDilate(rawMask, w, h, radius = 2)
        return morphErode(dilated, w, h, radius = 2)
    }

    private fun otsuThreshold(values: FloatArray): Float {
        val hist = IntArray(256)
        for (v in values) {
            hist[v.roundToInt().coerceIn(0, 255)]++
        }
        val total = values.size.toDouble()
        var sum = 0.0
        for (t in 0..255) sum += t * hist[t]

        var sumB = 0.0
        var wB = 0.0
        var maxBetween = -1.0
        var bestThresh = 128

        for (t in 0..255) {
            wB += hist[t]
            if (wB == 0.0) continue
            val wF = total - wB
            if (wF == 0.0) break
            sumB += t * hist[t]
            val mB = sumB / wB
            val mF = (sum - sumB) / wF
            val between = wB * wF * (mB - mF) * (mB - mF)
            if (between > maxBetween) {
                maxBetween = between
                bestThresh = t
            }
        }
        return bestThresh.toFloat()
    }

    private fun morphDilate(mask: BooleanArray, w: Int, h: Int, radius: Int): BooleanArray {
        val out = BooleanArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                var hit = false
                loop@ for (dy in -radius..radius) {
                    val ny = y + dy
                    if (ny !in 0 until h) continue
                    for (dx in -radius..radius) {
                        val nx = x + dx
                        if (nx !in 0 until w) continue
                        if (mask[ny * w + nx]) {
                            hit = true
                            break@loop
                        }
                    }
                }
                out[y * w + x] = hit
            }
        }
        return out
    }

    private fun morphErode(mask: BooleanArray, w: Int, h: Int, radius: Int): BooleanArray {
        val out = BooleanArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                var allTrue = true
                loop@ for (dy in -radius..radius) {
                    val ny = y + dy
                    if (ny !in 0 until h) {
                        allTrue = false
                        break@loop
                    }
                    for (dx in -radius..radius) {
                        val nx = x + dx
                        if (nx !in 0 until w || !mask[ny * w + nx]) {
                            allTrue = false
                            break@loop
                        }
                    }
                }
                out[y * w + x] = allTrue
            }
        }
        return out
    }
}
