package com.example.engine

import android.graphics.Bitmap
import com.example.domain.model.DrawingStep
import com.example.domain.model.DrawingStroke
import com.example.domain.model.DrawingTutorial
import com.example.domain.model.StrokePoint
import com.example.domain.model.StrokeStyle
import com.example.domain.model.TutorialStage
import java.util.UUID
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class ProcessingStage(val stepIndex: Int) {
    SHAPES(0),
    OUTLINES(1),
    DETAILS(2),
    SHADING(3)
}

object DrawingTutorialGenerator {

    fun generateFromBitmap(
        title: String,
        bitmap: Bitmap,
        onStageProgress: (ProcessingStage) -> Unit = {}
    ): DrawingTutorial {
        val safeBitmap = if (bitmap.config == Bitmap.Config.ARGB_8888) {
            bitmap
        } else {
            bitmap.copy(Bitmap.Config.ARGB_8888, false) ?: bitmap
        }
        val w = safeBitmap.width
        val h = safeBitmap.height
        val pixels = IntArray(w * h)
        safeBitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        if (safeBitmap !== bitmap) {
            safeBitmap.recycle()
        }
        return generateFromPixels(
            title = title,
            pixelBuffer = PixelBuffer(w, h, pixels),
            onStageProgress = onStageProgress
        )
    }

    fun generateFromPixels(
        title: String,
        pixelBuffer: PixelBuffer,
        onStageProgress: (ProcessingStage) -> Unit = {}
    ): DrawingTutorial {
        val safeTitle = title.ifBlank { "Sketch Study" }
        val normalized = ImageProcessingUtils.downsamplePixelBuffer(pixelBuffer, maxDim = 340)
        val w = normalized.width
        val h = normalized.height
        val aspectRatio = (w.toFloat() / h.toFloat().coerceAtLeast(1f)).coerceIn(0.45f, 2.2f)

        onStageProgress(ProcessingStage.SHAPES)
        val rawLum = ImageProcessingUtils.extractLuminance(normalized)
        val lum = ImageProcessingUtils.contrastStretch(rawLum)
        val fineSobel = ImageProcessingUtils.computeSobel(
            ImageProcessingUtils.gaussianBlur(lum, w, h, sigma = 1.0f),
            w,
            h
        )
        val fgMask = ImageProcessingUtils.computeSaliencyMask(normalized, lum, fineSobel.mag)
        val fgCount = fgMask.count { it }
        val hasSalientFg = fgCount in (w * h / 40)..(w * h * 85 / 100)
        val components = ContourAndShapeExtractor.extractSalientComponents(fgMask, w, h, maxComponents = 2)
        val basicShapeStrokes = ContourAndShapeExtractor.buildBasicShapeStrokes(components, w, h)

        onStageProgress(ProcessingStage.OUTLINES)
        // Stage 2: Main outlines from medium-coarse Canny edge map
        val coarseEdges = ImageProcessingUtils.cannyEdges(
            lum = lum,
            w = w,
            h = h,
            sigma = 1.9f,
            lowRatio = 0.42f,
            highPercentile = 0.80f
        )
        val minOutlineLen = max(14f, min(w, h) * 0.08f)
        val rawOutlines = ContourAndShapeExtractor.traceContours(
            edgeMap = coarseEdges,
            w = w,
            h = h,
            sobelMag = fineSobel.mag,
            foregroundMask = fgMask,
            minLengthPx = minOutlineLen,
            rdpEpsilonPx = 1.35f
        )
        val maxOutlineCount = 26
        val outlinePolylines = rawOutlines.take(maxOutlineCount)
        val outlineExclusion = ContourAndShapeExtractor.markDrawnExclusionMask(
            polylines = outlinePolylines,
            w = w,
            h = h,
            radiusPx = 2
        )

        onStageProgress(ProcessingStage.DETAILS)
        // Stage 3 & 4: Internal and additional details from fine Canny edge map (non-overlapping)
        val fineEdges = ImageProcessingUtils.cannyEdges(
            lum = lum,
            w = w,
            h = h,
            sigma = 0.95f,
            lowRatio = 0.38f,
            highPercentile = 0.66f
        )
        val minDetailLen = max(6f, min(w, h) * 0.03f)
        val rawDetails = ContourAndShapeExtractor.traceContours(
            edgeMap = fineEdges,
            w = w,
            h = h,
            sobelMag = fineSobel.mag,
            foregroundMask = fgMask,
            excludedMask = outlineExclusion,
            minLengthPx = minDetailLen,
            rdpEpsilonPx = 0.95f
        )

        val internalDetailPolylines = rawDetails
            .filter { !hasSalientFg || it.foregroundFraction >= 0.30f || it.lengthPx >= minOutlineLen * 0.7f }
            .take(55)
        val internalSet = internalDetailPolylines.toHashSet()
        val additionalDetailPolylines = rawDetails
            .filter { it !in internalSet }
            .take(45)

        onStageProgress(ProcessingStage.SHADING)
        // Stage 5: True pencil hatching shading strokes
        val allShadingStrokes = ContourAndShapeExtractor.generateShadingStrokes(
            lum = lum,
            w = w,
            h = h,
            foregroundMask = fgMask,
            hasSalientForeground = hasSalientFg
        ).take(90)

        // Convert polylines to DrawingStrokes
        val outlineStrokes = outlinePolylines.map { poly ->
            DrawingStroke(
                points = poly.points,
                style = StrokeStyle.OUTLINE,
                strokeWidth = 2.9f,
                alpha = 0.96f
            )
        }
        val internalStrokes = internalDetailPolylines.map { poly ->
            DrawingStroke(
                points = poly.points,
                style = StrokeStyle.DETAIL,
                strokeWidth = 2.0f,
                alpha = 0.90f
            )
        }
        val additionalStrokes = additionalDetailPolylines.map { poly ->
            DrawingStroke(
                points = poly.points,
                style = StrokeStyle.FINE_DETAIL,
                strokeWidth = 1.45f,
                alpha = 0.80f
            )
        }

        // Hold back a crisp subset of final accent strokes for the Final Step (Completed Drawing)
        val finalAccents = ArrayList<DrawingStroke>()
        val mainInternalStrokes = if (internalStrokes.size > 4) {
            finalAccents.addAll(internalStrokes.takeLast(2))
            internalStrokes.dropLast(2)
        } else internalStrokes
        val mainAdditionalStrokes = if (additionalStrokes.size > 4) {
            finalAccents.addAll(additionalStrokes.takeLast(3))
            additionalStrokes.dropLast(3)
        } else additionalStrokes
        val mainShadingStrokes = if (allShadingStrokes.size > 6) {
            finalAccents.addAll(allShadingStrokes.takeLast(4))
            allShadingStrokes.dropLast(4)
        } else allShadingStrokes

        // Build progressive 10..50 steps
        val totalStrokes = basicShapeStrokes.size +
            outlineStrokes.size +
            mainInternalStrokes.size +
            mainAdditionalStrokes.size +
            mainShadingStrokes.size +
            finalAccents.size

        val steps = buildProgressiveSteps(
            basicShapes = basicShapeStrokes,
            outlines = outlineStrokes,
            internalDetails = mainInternalStrokes,
            additionalDetails = mainAdditionalStrokes,
            shading = mainShadingStrokes,
            finalAccents = finalAccents,
            totalStrokeCount = totalStrokes
        )

        val now = System.currentTimeMillis()
        return DrawingTutorial(
            id = UUID.randomUUID().toString(),
            title = safeTitle,
            aspectRatio = aspectRatio,
            steps = steps,
            currentStepIndex = 0,
            isCompleted = false,
            createdAt = now,
            updatedAt = now
        )
    }

    private fun buildProgressiveSteps(
        basicShapes: List<DrawingStroke>,
        outlines: List<DrawingStroke>,
        internalDetails: List<DrawingStroke>,
        additionalDetails: List<DrawingStroke>,
        shading: List<DrawingStroke>,
        finalAccents: List<DrawingStroke>,
        totalStrokeCount: Int
    ): List<DrawingStep> {
        // Scale total steps cleanly in [10, 50] based on complexity
        val targetTotalSteps = (10 + (totalStrokeCount / 5)).coerceIn(10, 48)
        val steps = ArrayList<DrawingStep>(targetTotalSteps)

        // Reserve 1 step for FINAL_TOUCH at the end
        val remainingSteps = (targetTotalSteps - 1).coerceAtLeast(9)

        val stageInputs = listOf(
            TutorialStage.BASIC_SHAPES to sortStrokesSpatially(basicShapes),
            TutorialStage.MAIN_OUTLINE to sortStrokesSpatially(outlines),
            TutorialStage.INTERNAL_DETAILS to sortStrokesSpatially(internalDetails),
            TutorialStage.ADDITIONAL_DETAILS to sortStrokesSpatially(additionalDetails),
            TutorialStage.SHADING to sortStrokesSpatially(shading)
        ).filter { it.second.isNotEmpty() }

        val stageBudgets = allocateStepBudgets(stageInputs, remainingSteps)

        var stepNum = 1
        for ((stage, strokes) in stageInputs) {
            val budget = stageBudgets[stage] ?: 1
            val chunks = chunkStrokes(strokes, budget)
            chunks.forEachIndexed { chunkIdx, chunk ->
                steps.add(
                    DrawingStep(
                        stepNumber = stepNum++,
                        stage = stage,
                        instruction = buildInstruction(stage, chunk, chunkIdx, chunks.size),
                        strokes = chunk
                    )
                )
            }
        }

        // Pad if image was ultra-minimal (ensures strictly >= 10 steps)
        while (steps.size < 9) {
            val lastStroke = steps.lastOrNull()?.strokes?.firstOrNull()
                ?: DrawingStroke(
                    points = listOf(StrokePoint(0.3f, 0.5f), StrokePoint(0.7f, 0.5f)),
                    style = StrokeStyle.OUTLINE
                )
            steps.add(
                DrawingStep(
                    stepNumber = stepNum++,
                    stage = TutorialStage.INTERNAL_DETAILS,
                    instruction = "Refine the contour weight and align proportions.",
                    strokes = listOf(lastStroke.copy(strokeWidth = 1.6f, alpha = 0.5f))
                )
            )
        }

        // Final step: Completed drawing with finishing touches
        val finalStrokes = when {
            finalAccents.isNotEmpty() -> finalAccents
            outlines.isNotEmpty() -> listOf(outlines.first().copy(strokeWidth = 3.1f, alpha = 0.85f))
            else -> steps.lastOrNull()?.strokes ?: basicShapes.take(1)
        }
        steps.add(
            DrawingStep(
                stepNumber = stepNum,
                stage = TutorialStage.FINAL_TOUCH,
                instruction = "Add final accent strokes to complete your drawing.",
                strokes = finalStrokes
            )
        )

        // Ensure strictly clamped <= 50 steps and contiguous 1-based stepNumber
        val clamped = if (steps.size > 50) {
            steps.take(49) + steps.last()
        } else {
            steps
        }

        return clamped.mapIndexed { idx, step ->
            step.copy(stepNumber = idx + 1)
        }
    }

    private fun allocateStepBudgets(
        stageInputs: List<Pair<TutorialStage, List<DrawingStroke>>>,
        totalBudget: Int
    ): Map<TutorialStage, Int> {
        val result = LinkedHashMap<TutorialStage, Int>()
        if (stageInputs.isEmpty()) return result

        // Weight outlines & internal details higher so core drawing progression is crystal clear
        val weights = stageInputs.associate { (stage, strokes) ->
            val stageWeight = when (stage) {
                TutorialStage.BASIC_SHAPES -> min(3, strokes.size).toFloat()
                TutorialStage.MAIN_OUTLINE -> strokes.size * 1.45f
                TutorialStage.INTERNAL_DETAILS -> strokes.size * 1.25f
                TutorialStage.ADDITIONAL_DETAILS -> strokes.size * 0.9f
                TutorialStage.SHADING -> strokes.size * 0.6f
                TutorialStage.FINAL_TOUCH -> 1f
            }
            stage to max(1f, stageWeight)
        }

        var assigned = 0
        for ((stage, strokes) in stageInputs) {
            val minSteps = 1
            result[stage] = minSteps.coerceAtMost(strokes.size)
            assigned += result[stage]!!
        }

        val totalWeight = weights.values.sum().coerceAtLeast(1f)
        var remaining = (totalBudget - assigned).coerceAtLeast(0)

        while (remaining > 0) {
            var addedAny = false
            val orderedByDeficit = stageInputs.sortedByDescending { (stage, strokes) ->
                val ideal = (weights[stage]!! / totalWeight) * totalBudget
                val current = result[stage] ?: 1
                if (current >= strokes.size) -1000f else ideal - current
            }
            for ((stage, strokes) in orderedByDeficit) {
                if (remaining <= 0) break
                val current = result[stage] ?: 1
                val maxCap = when (stage) {
                    TutorialStage.BASIC_SHAPES -> min(strokes.size, 3)
                    TutorialStage.SHADING -> min(strokes.size, 8)
                    else -> strokes.size
                }
                if (current < maxCap) {
                    result[stage] = current + 1
                    remaining--
                    addedAny = true
                }
            }
            if (!addedAny) break
        }

        return result
    }

    private fun chunkStrokes(strokes: List<DrawingStroke>, chunkCount: Int): List<List<DrawingStroke>> {
        val count = chunkCount.coerceIn(1, max(1, strokes.size))
        val chunks = ArrayList<List<DrawingStroke>>(count)
        var start = 0
        for (i in 0 until count) {
            val remainingItems = strokes.size - start
            val remainingBuckets = count - i
            val size = ceil(remainingItems.toFloat() / remainingBuckets.toFloat()).toInt()
            chunks.add(strokes.subList(start, start + size))
            start += size
        }
        return chunks
    }

    private fun sortStrokesSpatially(strokes: List<DrawingStroke>): List<DrawingStroke> {
        return strokes.sortedWith(
            compareBy<DrawingStroke> { stroke ->
                val avgY = stroke.points.map { it.y }.average()
                (avgY * 4.0).toInt() // Top-to-bottom bands
            }.thenBy { stroke ->
                stroke.points.map { it.x }.average() // Left-to-right within band
            }
        )
    }

    private fun buildInstruction(
        stage: TutorialStage,
        strokes: List<DrawingStroke>,
        chunkIdx: Int,
        totalChunks: Int
    ): String {
        val region = describeRegion(strokes)
        return when (stage) {
            TutorialStage.BASIC_SHAPES -> when (chunkIdx) {
                0 -> "Lightly sketch the primary guide shapes in the $region to set proportions."
                else -> "Add the alignment axis and secondary guide lines in the $region."
            }
            TutorialStage.MAIN_OUTLINE -> when {
                chunkIdx == 0 -> "Trace the main outer contour lines in the $region."
                chunkIdx == totalChunks - 1 -> "Complete the outer silhouette edges in the $region."
                else -> "Continue building the primary outline across the $region."
            }
            TutorialStage.INTERNAL_DETAILS -> when {
                chunkIdx == 0 -> "Draw the key interior feature lines in the $region."
                else -> "Add the inner structural details in the $region."
            }
            TutorialStage.ADDITIONAL_DETAILS ->
                "Refine secondary accents and fine lines in the $region."
            TutorialStage.SHADING -> when {
                strokes.any { it.alpha > 0.4f } ->
                    "Add deeper cross-hatching strokes in the $region for contrast."
                else ->
                    "Shade the mid-tone shadow areas in the $region with light parallel strokes."
            }
            TutorialStage.FINAL_TOUCH ->
                "Add final accent strokes to complete your drawing."
        }
    }

    private fun describeRegion(strokes: List<DrawingStroke>): String {
        val allPts = strokes.flatMap { it.points }
        if (allPts.isEmpty()) return "center"
        val cx = allPts.map { it.x }.average().toFloat()
        val cy = allPts.map { it.y }.average().toFloat()

        val vPos = when {
            cy < 0.36f -> "upper"
            cy > 0.64f -> "lower"
            else -> ""
        }
        val hPos = when {
            cx < 0.36f -> "left"
            cx > 0.64f -> "right"
            else -> ""
        }
        return when {
            vPos.isEmpty() && hPos.isEmpty() -> "center"
            vPos.isNotEmpty() && hPos.isEmpty() -> "$vPos area"
            vPos.isEmpty() && hPos.isNotEmpty() -> "$hPos side"
            else -> "$vPos-$hPos area"
        }
    }
}
