package com.example.ui.components

import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.domain.model.DrawingStep
import com.example.domain.model.DrawingStroke
import com.example.domain.model.StrokeStyle
import com.example.ui.theme.CanvasBorderLight
import com.example.ui.theme.CanvasPaperWhite
import kotlin.math.max
import kotlin.math.min

@Composable
fun AnimatedDrawingCanvas(
    steps: List<DrawingStep>,
    currentStepIndex: Int,
    stepAnimationProgress: Float,
    aspectRatio: Float,
    contentDescriptionText: String,
    modifier: Modifier = Modifier
) {
    val safeAspect = aspectRatio.coerceIn(0.45f, 2.2f)
    val safeIndex = currentStepIndex.coerceIn(0, (steps.size - 1).coerceAtLeast(0))

    val strokePaint = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
    }
    val pencilTipPaint = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }
    }
    val dashEffect = remember { DashPathEffect(floatArrayOf(12f, 8f), 0f) }

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .aspectRatio(safeAspect)
                .shadow(elevation = 6.dp, shape = RoundedCornerShape(18.dp), clip = false)
                .clip(RoundedCornerShape(18.dp))
                .background(CanvasPaperWhite)
                .border(1.dp, CanvasBorderLight, RoundedCornerShape(18.dp))
                .padding(10.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("drawing_canvas")
                    .semantics { contentDescription = contentDescriptionText }
            ) {
                val canvasW = size.width
                val canvasH = size.height
                if (canvasW <= 1f || canvasH <= 1f || steps.isEmpty()) return@Canvas

                val scaleFactor = min(canvasW, canvasH) / 360f
                val isPastConstruction = safeIndex > 1

                drawIntoCanvas { composeCanvas ->
                    val nativeCanvas = composeCanvas.nativeCanvas

                    // 1. Draw all previously completed steps at 100%
                    for (i in 0 until safeIndex) {
                        val prevStep = steps[i]
                        for (stroke in prevStep.strokes) {
                            val path = buildSmoothPath(stroke, canvasW, canvasH)
                            configurePaintForStroke(
                                paint = strokePaint,
                                style = stroke.style,
                                baseStrokeWidth = stroke.strokeWidth * scaleFactor,
                                alpha = if (stroke.style == StrokeStyle.CONSTRUCTION && isPastConstruction) {
                                    stroke.alpha * 0.42f
                                } else {
                                    stroke.alpha
                                },
                                isActiveHighlight = false,
                                dashEffect = dashEffect
                            )
                            nativeCanvas.drawPath(path, strokePaint)
                        }
                    }

                    // 2. Animate current step's strokes sequentially as if drawn by a pencil
                    val activeStep = steps[safeIndex]
                    val activePaths = activeStep.strokes.map { stroke ->
                        val path = buildSmoothPath(stroke, canvasW, canvasH)
                        val pm = PathMeasure(path, false)
                        Triple(stroke, path, max(1f, pm.length))
                    }
                    val totalLen = activePaths.sumOf { it.third.toDouble() }.toFloat().coerceAtLeast(1f)
                    val targetDrawnLen = totalLen * stepAnimationProgress.coerceIn(0f, 1f)

                    var accumulated = 0f
                    var activeTipX: Float? = null
                    var activeTipY: Float? = null
                    var activeTanX = 1f
                    var activeTanY = -1f

                    for ((stroke, fullPath, len) in activePaths) {
                        if (accumulated >= targetDrawnLen && stepAnimationProgress < 0.999f) {
                            break
                        }

                        val remainingForStroke = (targetDrawnLen - accumulated).coerceIn(0f, len)
                        val isCompleteStroke = remainingForStroke >= len - 0.5f || stepAnimationProgress >= 0.999f

                        configurePaintForStroke(
                            paint = strokePaint,
                            style = stroke.style,
                            baseStrokeWidth = stroke.strokeWidth * scaleFactor,
                            alpha = stroke.alpha,
                            isActiveHighlight = stepAnimationProgress < 0.999f,
                            dashEffect = dashEffect
                        )

                        if (isCompleteStroke) {
                            nativeCanvas.drawPath(fullPath, strokePaint)
                        } else if (remainingForStroke > 0.5f) {
                            val partialPath = Path()
                            val pm = PathMeasure(fullPath, false)
                            pm.getSegment(0f, remainingForStroke, partialPath, true)
                            nativeCanvas.drawPath(partialPath, strokePaint)

                            val pos = FloatArray(2)
                            val tan = FloatArray(2)
                            if (pm.getPosTan(remainingForStroke, pos, tan)) {
                                activeTipX = pos[0]
                                activeTipY = pos[1]
                                activeTanX = tan[0]
                                activeTanY = tan[1]
                            }
                        }
                        accumulated += len
                    }

                    // 3. Draw moving pencil nib indicator while drawing animation is active
                    val tipX = activeTipX
                    val tipY = activeTipY
                    if (tipX != null && tipY != null && stepAnimationProgress < 0.995f) {
                        drawPencilNib(
                            nativeCanvas = nativeCanvas,
                            tipX = tipX,
                            tipY = tipY,
                            scaleFactor = scaleFactor,
                            paint = pencilTipPaint,
                            tanX = activeTanX,
                            tanY = activeTanY
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DrawingThumbnailCanvas(
    steps: List<DrawingStep>,
    upToStepIndex: Int,
    aspectRatio: Float,
    modifier: Modifier = Modifier
) {
    val safeAspect = aspectRatio.coerceIn(0.55f, 1.8f)
    val maxIdx = upToStepIndex.coerceIn(0, (steps.size - 1).coerceAtLeast(0))

    val strokePaint = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
    }
    val dashEffect = remember { DashPathEffect(floatArrayOf(6f, 4f), 0f) }

    Box(
        modifier = modifier
            .aspectRatio(safeAspect)
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White)
            .border(1.dp, CanvasBorderLight, RoundedCornerShape(12.dp))
            .padding(4.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasW = size.width
            val canvasH = size.height
            if (canvasW <= 1f || canvasH <= 1f || steps.isEmpty()) return@Canvas

            val scaleFactor = max(0.32f, min(canvasW, canvasH) / 360f)

            drawIntoCanvas { composeCanvas ->
                val nativeCanvas = composeCanvas.nativeCanvas
                for (i in 0..maxIdx) {
                    val step = steps[i]
                    for (stroke in step.strokes) {
                        val path = buildSmoothPath(stroke, canvasW, canvasH)
                        configurePaintForStroke(
                            paint = strokePaint,
                            style = stroke.style,
                            baseStrokeWidth = max(1.1f, stroke.strokeWidth * scaleFactor * 1.3f),
                            alpha = if (stroke.style == StrokeStyle.CONSTRUCTION && maxIdx > 1) {
                                stroke.alpha * 0.35f
                            } else {
                                stroke.alpha
                            },
                            isActiveHighlight = false,
                            dashEffect = dashEffect
                        )
                        nativeCanvas.drawPath(path, strokePaint)
                    }
                }
            }
        }
    }
}

private fun buildSmoothPath(
    stroke: DrawingStroke,
    canvasW: Float,
    canvasH: Float
): Path {
    val path = Path()
    val pts = stroke.points
    if (pts.isEmpty()) return path

    val x0 = pts[0].x * canvasW
    val y0 = pts[0].y * canvasH
    path.moveTo(x0, y0)

    if (pts.size == 2) {
        path.lineTo(pts[1].x * canvasW, pts[1].y * canvasH)
        return path
    }

    for (i in 1 until pts.lastIndex) {
        val xc = pts[i].x * canvasW
        val yc = pts[i].y * canvasH
        val xn = pts[i + 1].x * canvasW
        val yn = pts[i + 1].y * canvasH
        val midX = (xc + xn) * 0.5f
        val midY = (yc + yn) * 0.5f
        path.quadTo(xc, yc, midX, midY)
    }

    val last = pts.last()
    path.lineTo(last.x * canvasW, last.y * canvasH)
    if (stroke.isClosed) path.close()
    return path
}

private fun configurePaintForStroke(
    paint: Paint,
    style: StrokeStyle,
    baseStrokeWidth: Float,
    alpha: Float,
    isActiveHighlight: Boolean,
    dashEffect: DashPathEffect
) {
    paint.pathEffect = if (style == StrokeStyle.CONSTRUCTION) dashEffect else null
    paint.strokeWidth = baseStrokeWidth.coerceAtLeast(0.8f)

    val rgb = when {
        isActiveHighlight && style != StrokeStyle.CONSTRUCTION -> 0xC85A32 // Warm terracotta-pencil active stroke
        style == StrokeStyle.CONSTRUCTION -> 0x8C847A
        style == StrokeStyle.OUTLINE -> 0x1E1B18
        style == StrokeStyle.DETAIL -> 0x2A2622
        style == StrokeStyle.FINE_DETAIL -> 0x45403B
        style == StrokeStyle.SHADING -> 0x3A3531
        else -> 0x1E1B18
    }
    val alphaInt = (alpha.coerceIn(0.05f, 1f) * 255).toInt()
    paint.color = (alphaInt shl 24) or rgb
}

private fun drawPencilNib(
    nativeCanvas: android.graphics.Canvas,
    tipX: Float,
    tipY: Float,
    scaleFactor: Float,
    paint: Paint,
    tanX: Float,
    tanY: Float
) {
    val s = scaleFactor.coerceIn(0.6f, 2.2f)

    // Soft halo at contact point
    paint.color = 0x33C85A32
    nativeCanvas.drawCircle(tipX, tipY, 7f * s, paint)

    // Angled stylized wooden pencil body pointing cleanly to (tipX, tipY)
    nativeCanvas.save()
    nativeCanvas.translate(tipX, tipY)
    // Angle pencil upward-right at ~45 deg like a natural right-handed artist grip
    nativeCanvas.rotate(-40f + (tanX * 4f + tanY * 4f).coerceIn(-8f, 8f))

    // Graphite tip cone
    val tipPath = Path().apply {
        moveTo(0f, 0f)
        lineTo(8f * s, -4.5f * s)
        lineTo(8f * s, 4.5f * s)
        close()
    }
    paint.color = 0xFF221F1D.toInt()
    nativeCanvas.drawPath(tipPath, paint)

    // Wood collar
    val woodPath = Path().apply {
        moveTo(8f * s, -4.5f * s)
        lineTo(15f * s, -6f * s)
        lineTo(15f * s, 6f * s)
        lineTo(8f * s, 4.5f * s)
        close()
    }
    paint.color = 0xFFE6C29F.toInt()
    nativeCanvas.drawPath(woodPath, paint)

    // Terracotta-orange pencil barrel
    paint.color = 0xFFC85A32.toInt()
    nativeCanvas.drawRect(15f * s, -6f * s, 46f * s, 6f * s, paint)

    // Metal ferrule & eraser
    paint.color = 0xFFD0C9C0.toInt()
    nativeCanvas.drawRect(46f * s, -6f * s, 51f * s, 6f * s, paint)
    paint.color = 0xFFE38B7A.toInt()
    nativeCanvas.drawRect(51f * s, -5.5f * s, 57f * s, 5.5f * s, paint)

    nativeCanvas.restore()
}
