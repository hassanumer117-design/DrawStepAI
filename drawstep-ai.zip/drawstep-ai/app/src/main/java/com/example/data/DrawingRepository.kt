package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.util.Log
import com.example.data.local.DrawingTutorialDao
import com.example.data.local.DrawingTutorialEntity
import com.example.domain.model.DrawingStep
import com.example.domain.model.DrawingTutorial
import com.example.engine.DrawingTutorialGenerator
import com.example.engine.ProcessingStage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlin.math.max
import kotlin.math.roundToInt

class DrawingRepository(
    private val dao: DrawingTutorialDao
) {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun observeAllTutorials(): Flow<List<DrawingTutorial>> {
        return dao.observeAllTutorials().map { entities ->
            entities.mapNotNull { it.toDomainOrNull() }
        }
    }

    fun observeTutorial(id: String): Flow<DrawingTutorial?> {
        return dao.observeTutorialById(id).map { entity ->
            entity?.toDomainOrNull()
        }
    }

    suspend fun createTutorialFromUri(
        context: Context,
        uri: Uri,
        onStageProgress: (ProcessingStage) -> Unit
    ): Result<DrawingTutorial> = withContext(Dispatchers.Default) {
        runCatching {
            val title = resolveDisplayTitle(context, uri)
            val bitmap = decodeScaledBitmap(context, uri, maxDimension = 680)
                ?: throw IllegalStateException("Failed to decode image from URI: $uri")
            try {
                val tutorial = DrawingTutorialGenerator.generateFromBitmap(
                    title = title,
                    bitmap = bitmap,
                    onStageProgress = onStageProgress
                )
                saveTutorial(tutorial)
                tutorial
            } finally {
                bitmap.recycle()
            }
        }.onFailure { error ->
            Log.e(TAG, "createTutorialFromUri failed for $uri", error)
        }
    }

    suspend fun saveTutorial(tutorial: DrawingTutorial) = withContext(Dispatchers.IO) {
        dao.upsertTutorial(tutorial.toEntity())
    }

    suspend fun updateStepProgress(
        id: String,
        stepIndex: Int,
        totalSteps: Int
    ) = withContext(Dispatchers.IO) {
        val clampedIndex = stepIndex.coerceIn(0, (totalSteps - 1).coerceAtLeast(0))
        val isCompleted = totalSteps > 0 && clampedIndex >= totalSteps - 1
        dao.updateProgress(
            id = id,
            stepIndex = clampedIndex,
            isCompleted = isCompleted,
            updatedAt = System.currentTimeMillis()
        )
    }

    suspend fun deleteTutorial(id: String) = withContext(Dispatchers.IO) {
        dao.deleteTutorialById(id)
    }

    private fun resolveDisplayTitle(context: Context, uri: Uri): String {
        val fallback = "Drawing Study"
        val rawName = runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) cursor.getString(idx) else null
                    } else null
                }
        }.getOrNull() ?: uri.lastPathSegment

        if (rawName.isNullOrBlank()) return fallback
        val cleaned = rawName
            .substringAfterLast('/')
            .substringBeforeLast('.')
            .replace('_', ' ')
            .replace('-', ' ')
            .trim()
        return if (cleaned.isBlank() || cleaned.all { it.isDigit() }) {
            fallback
        } else {
            cleaned.take(28).replaceFirstChar { it.uppercase() }
        }
    }

    private fun decodeScaledBitmap(
        context: Context,
        uri: Uri,
        maxDimension: Int
    ): Bitmap? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val decodedWithImageDecoder = runCatching {
                decodeWithImageDecoder(context, uri, maxDimension)
            }.onFailure { err ->
                Log.w(TAG, "ImageDecoder failed, falling back to BitmapFactory", err)
            }.getOrNull()
            if (decodedWithImageDecoder != null) {
                return ensureSoftwareArgb8888(decodedWithImageDecoder)
            }
        }
        return decodeWithBitmapFactory(context, uri, maxDimension)
            ?.let { ensureSoftwareArgb8888(it) }
    }

    @androidx.annotation.RequiresApi(Build.VERSION_CODES.P)
    private fun decodeWithImageDecoder(
        context: Context,
        uri: Uri,
        maxDimension: Int
    ): Bitmap {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            decoder.isMutableRequired = false
            val srcW = info.size.width
            val srcH = info.size.height
            val longest = max(srcW, srcH)
            if (longest > maxDimension && srcW > 0 && srcH > 0) {
                val scale = maxDimension.toFloat() / longest.toFloat()
                val targetW = max(16, (srcW * scale).roundToInt())
                val targetH = max(16, (srcH * scale).roundToInt())
                decoder.setTargetSize(targetW, targetH)
            }
        }
    }

    private fun decodeWithBitmapFactory(
        context: Context,
        uri: Uri,
        maxDimension: Int
    ): Bitmap? {
        val resolver = context.contentResolver
        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val openedBounds = resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, boundsOpts)
            true
        } ?: false
        if (!openedBounds) return null

        val srcW = boundsOpts.outWidth
        val srcH = boundsOpts.outHeight
        if (srcW <= 0 || srcH <= 0) return null

        var sampleSize = 1
        while (max(srcW / sampleSize, srcH / sampleSize) > maxDimension * 2) {
            sampleSize *= 2
        }

        val decodeOpts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val rawBitmap = resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, decodeOpts)
        } ?: return null

        val orientation = runCatching {
            resolver.openInputStream(uri)?.use { stream ->
                ExifInterface(stream).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
        }

        return if (!matrix.isIdentity) {
            val rotated = Bitmap.createBitmap(
                rawBitmap,
                0,
                0,
                rawBitmap.width,
                rawBitmap.height,
                matrix,
                true
            )
            if (rotated !== rawBitmap) rawBitmap.recycle()
            rotated
        } else {
            rawBitmap
        }
    }

    private fun ensureSoftwareArgb8888(bitmap: Bitmap): Bitmap {
        if (bitmap.config == Bitmap.Config.ARGB_8888) return bitmap
        val converted = bitmap.copy(Bitmap.Config.ARGB_8888, false)
        if (converted != null) {
            if (converted !== bitmap) bitmap.recycle()
            return converted
        }
        return bitmap
    }

    private fun DrawingTutorial.toEntity(): DrawingTutorialEntity {
        return DrawingTutorialEntity(
            id = id,
            title = title,
            aspectRatio = aspectRatio,
            stepsJson = json.encodeToString(steps),
            totalSteps = steps.size,
            currentStepIndex = currentStepIndex,
            isCompleted = isCompleted,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }

    private fun DrawingTutorialEntity.toDomainOrNull(): DrawingTutorial? {
        return runCatching {
            val decodedSteps = json.decodeFromString<List<DrawingStep>>(stepsJson)
            DrawingTutorial(
                id = id,
                title = title,
                aspectRatio = aspectRatio,
                steps = decodedSteps,
                currentStepIndex = currentStepIndex,
                isCompleted = isCompleted,
                createdAt = createdAt,
                updatedAt = updatedAt
            )
        }.getOrNull()
    }

    private companion object {
        const val TAG = "DrawingRepository"
    }
}
