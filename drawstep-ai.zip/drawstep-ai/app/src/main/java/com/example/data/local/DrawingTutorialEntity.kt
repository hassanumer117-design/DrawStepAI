package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "drawing_tutorials")
data class DrawingTutorialEntity(
    @PrimaryKey val id: String,
    val title: String,
    val aspectRatio: Float,
    val stepsJson: String,
    val totalSteps: Int,
    val currentStepIndex: Int,
    val isCompleted: Boolean,
    val createdAt: Long,
    val updatedAt: Long
)
