package com.example.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class StrokePoint(
    val x: Float,
    val y: Float
)

@Serializable
enum class StrokeStyle {
    CONSTRUCTION,
    OUTLINE,
    DETAIL,
    FINE_DETAIL,
    SHADING
}

@Serializable
data class DrawingStroke(
    val points: List<StrokePoint>,
    val style: StrokeStyle,
    val strokeWidth: Float = 2.4f,
    val alpha: Float = 1.0f,
    val isClosed: Boolean = false
)

@Serializable
enum class TutorialStage(val displayName: String) {
    BASIC_SHAPES("Basic Shapes"),
    MAIN_OUTLINE("Main Outline"),
    INTERNAL_DETAILS("Internal Details"),
    ADDITIONAL_DETAILS("Additional Details"),
    SHADING("Shading"),
    FINAL_TOUCH("Completed Drawing")
}

@Serializable
data class DrawingStep(
    val stepNumber: Int,
    val stage: TutorialStage,
    val instruction: String,
    val strokes: List<DrawingStroke>
)

data class DrawingTutorial(
    val id: String,
    val title: String,
    val aspectRatio: Float,
    val steps: List<DrawingStep>,
    val currentStepIndex: Int,
    val isCompleted: Boolean,
    val createdAt: Long,
    val updatedAt: Long
) {
    val totalSteps: Int get() = steps.size
}
