package com.example.ui.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.DrawingRepository
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.tutorial.TutorialScreen
import com.example.ui.tutorial.TutorialViewModel
import kotlinx.serialization.Serializable

@Serializable
object HomeRoute

@Serializable
data class TutorialRoute(val drawingId: String)

@Composable
fun DrawStepNavHost(repository: DrawingRepository) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = HomeRoute,
        enterTransition = { fadeIn() },
        exitTransition = { fadeOut() }
    ) {
        composable<HomeRoute> {
            val homeViewModel: HomeViewModel = viewModel(
                factory = HomeViewModel.Factory(repository)
            )
            HomeScreen(
                viewModel = homeViewModel,
                onOpenTutorial = { drawingId ->
                    navController.navigate(TutorialRoute(drawingId))
                }
            )
        }

        composable<TutorialRoute> { backStackEntry ->
            val route = backStackEntry.toRoute<TutorialRoute>()
            val tutorialViewModel: TutorialViewModel = viewModel(
                factory = TutorialViewModel.Factory(
                    drawingId = route.drawingId,
                    repository = repository
                )
            )
            TutorialScreen(
                viewModel = tutorialViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
