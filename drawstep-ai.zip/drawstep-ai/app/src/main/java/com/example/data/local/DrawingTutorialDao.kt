package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DrawingTutorialDao {

    @Query("SELECT * FROM drawing_tutorials ORDER BY updatedAt DESC")
    fun observeAllTutorials(): Flow<List<DrawingTutorialEntity>>

    @Query("SELECT * FROM drawing_tutorials WHERE id = :id LIMIT 1")
    fun observeTutorialById(id: String): Flow<DrawingTutorialEntity?>

    @Query("SELECT * FROM drawing_tutorials WHERE id = :id LIMIT 1")
    suspend fun getTutorialById(id: String): DrawingTutorialEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTutorial(entity: DrawingTutorialEntity)

    @Query(
        "UPDATE drawing_tutorials SET currentStepIndex = :stepIndex, isCompleted = :isCompleted, updatedAt = :updatedAt WHERE id = :id"
    )
    suspend fun updateProgress(
        id: String,
        stepIndex: Int,
        isCompleted: Boolean,
        updatedAt: Long
    )

    @Query("DELETE FROM drawing_tutorials WHERE id = :id")
    suspend fun deleteTutorialById(id: String)
}
