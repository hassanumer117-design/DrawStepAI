package com.example.ui.home

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.DrawingRepository
import com.example.domain.model.DrawingTutorial
import com.example.engine.ProcessingStage
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val drawings: List<DrawingTutorial> = emptyList(),
    val isProcessing: Boolean = false,
    val processingStage: ProcessingStage = ProcessingStage.SHAPES,
    val errorMessage: String? = null
)

sealed interface HomeEvent {
    data class NavigateToTutorial(val drawingId: String) : HomeEvent
}

class HomeViewModel(
    private val repository: DrawingRepository
) : ViewModel() {

    private val isProcessing = MutableStateFlow(false)
    private val processingStage = MutableStateFlow(ProcessingStage.SHAPES)
    private val errorMessage = MutableStateFlow<String?>(null)

    private val _events = MutableSharedFlow<HomeEvent>()
    val events: SharedFlow<HomeEvent> = _events.asSharedFlow()

    val uiState: StateFlow<HomeUiState> = combine(
        repository.observeAllTutorials(),
        isProcessing,
        processingStage,
        errorMessage
    ) { drawings, processing, stage, error ->
        HomeUiState(
            drawings = drawings,
            isProcessing = processing,
            processingStage = stage,
            errorMessage = error
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState()
    )

    fun onImageSelected(context: Context, uri: Uri) {
        if (isProcessing.value) return
        viewModelScope.launch {
            isProcessing.value = true
            processingStage.value = ProcessingStage.SHAPES
            errorMessage.value = null

            val result = repository.createTutorialFromUri(
                context = context.applicationContext,
                uri = uri,
                onStageProgress = { stage ->
                    processingStage.value = stage
                }
            )

            isProcessing.value = false
            result.onSuccess { tutorial ->
                _events.emit(HomeEvent.NavigateToTutorial(tutorial.id))
            }.onFailure {
                errorMessage.value = "Could not process the selected image. Please try another photo."
            }
        }
    }

    fun deleteDrawing(id: String) {
        viewModelScope.launch {
            repository.deleteTutorial(id)
        }
    }

    fun clearError() {
        errorMessage.value = null
    }

    class Factory(private val repository: DrawingRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HomeViewModel(repository) as T
        }
    }
}
