package com.example.engine

import com.example.domain.model.DrawingStroke
import com.example.domain.model.StrokePoint
import com.example.domain.model.StrokeStyle
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

data class TracedPolyline(
    val points: List<StrokePoint>,
    val saliencyScore: Float,
    val lengthPx: Float,
    val foregroundFraction: Float
)

data class SalientComponent(
    val centroidX: Float,
    val centroidY: Float,
    val angleRad: Float,
    val majorRadius: Float,
    val minorRadius: Float,
    val pixelCount: Int,
    val minX: Int,
    val maxX: Int,
    val minY: Int,
    val maxY: Int
)

object ContourAndShapeExtractor {

    private val neighborOffsets = arrayOf(
        1 to 0, 1 to 1, 0 to 1, -1 to 1,
        -1 to 0, -1 to -1, 0 to -1, 1 to -1
    )

    fun extractSalientComponents(
        mask: BooleanArray,
        w: Int,
        h: Int,
        maxComponents: Int = 2
    ): List<SalientComponent> {
        val labels = IntArray(w * h)
        val queue = IntArray(w * h)
        val components = ArrayList<SalientComponent>()
        var currentLabel = 1
        val minArea = max(36, (w * h * 0.015f).roundToInt())

        for (y in 0 until h) {
            for (x in 0 until w) {
                val startIdx = y * w + x
                if (!mask[startIdx] || labels[startIdx] != 0) continue

                var head = 0
                var tail = 0
                queue[tail++] = startIdx
                labels[startIdx] = currentLabel

                var count = 0
                var sumX = 0.0
                var sumY = 0.0
                var minX = x
                var maxX = x
                var minY = y
                var maxY = y

                val memberIndices = ArrayList<Int>()

                while (head < tail) {
                    val idx = queue[head++]
                    memberIndices.add(idx)
                    val cx = idx % w
                    val cy = idx / w
                    count++
                    sumX += cx
                    sumY += cy
                    if (cx < minX) minX = cx
                    if (cx > maxX) maxX = cx
                    if (cy < minY) minY = cy
                    if (cy > maxY) maxY = cy

                    for (dy in -1..1) {
                        val ny = cy + dy
                        if (ny !in 0 until h) continue
                        for (dx in -1..1) {
                            if (dx == 0 && dy == 0) continue
                            val nx = cx + dx
                            if (nx !in 0 until w) continue
                            val nIdx = ny * w + nx
                            if (mask[nIdx] && labels[nIdx] == 0) {
                                labels[nIdx] = currentLabel
                                queue[tail++] = nIdx
                            }
                        }
                    }
                }

                currentLabel++
                if (count < minArea) continue

                val mx = (sumX / count).toFloat()
                val my = (sumY / count).toFloat()
                var mu20 = 0.0
                var mu02 = 0.0
                var mu11 = 0.0
                for (idx in memberIndices) {
                    val dx = (idx % w) - mx
                    val dy = (idx / w) - my
                    mu20 += dx * dx
                    mu02 += dy * dy
                    mu11 += dx * dy
                }
                mu20 /= count
                mu02 /= count
                mu11 /= count

                val angle = 0.5 * atan2(2.0 * mu11, mu20 - mu02)
                val common = sqrt(4.0 * mu11 * mu11 + (mu20 - mu02) * (mu20 - mu02))
                val lambda1 = max(16.0, 0.5 * (mu20 + mu02 + common))
                val lambda2 = max(12.0, 0.5 * (mu20 + mu02 - common))

                val majorR = (2.0 * sqrt(lambda1)).toFloat().coerceIn(w * 0.06f, max(w, h) * 0.46f)
                val minorR = (2.0 * sqrt(lambda2)).toFloat().coerceIn(h * 0.05f, max(w, h) * 0.44f)

                components.add(
                    SalientComponent(
                        centroidX = mx / w.toFloat(),
                        centroidY = my / h.toFloat(),
                        angleRad = angle.toFloat(),
                        majorRadius = majorR / w.toFloat(),
                        minorRadius = minorR / h.toFloat(),
                        pixelCount = count,
                        minX = minX,
                        maxX = maxX,
                        minY = minY,
                        maxY = maxY
                    )
                )
            }
        }

        return components
            .sortedByDescending { it.pixelCount }
            .take(maxComponents)
    }

    fun buildBasicShapeStrokes(
        components: List<SalientComponent>,
        w: Int,
        h: Int
    ): List<DrawingStroke> {
        val strokes = ArrayList<DrawingStroke>()
        if (components.isEmpty()) {
            // Fallback balanced composition guide frame + central proportion oval
            strokes.add(
                createEllipseStroke(
                    cx = 0.5f,
                    cy = 0.5f,
                    rx = 0.30f,
                    ry = 0.34f,
                    angleRad = 0f
                )
            )
            strokes.add(
                DrawingStroke(
                    points = listOf(StrokePoint(0.5f, 0.12f), StrokePoint(0.5f, 0.88f)),
                    style = StrokeStyle.CONSTRUCTION,
                    strokeWidth = 1.4f,
                    alpha = 0.55f
                )
            )
            strokes.add(
                DrawingStroke(
                    points = listOf(StrokePoint(0.14f, 0.5f), StrokePoint(0.86f, 0.5f)),
                    style = StrokeStyle.CONSTRUCTION,
                    strokeWidth = 1.4f,
                    alpha = 0.55f
                )
            )
            return strokes
        }

        for (comp in components) {
            val aspect = max(comp.majorRadius, comp.minorRadius) / max(0.01f, min(comp.majorRadius, comp.minorRadius))
            val boxW = (comp.maxX - comp.minX).toFloat() / w.toFloat()
            val boxH = (comp.maxY - comp.minY).toFloat() / h.toFloat()

            if (aspect > 1.7f && max(boxW, boxH) > 0.35f) {
                // Split elongated subject (e.g. portrait bust, animal body, tall flower, car) into 2 overlapping proportion ovals
                val cosA = cos(comp.angleRad)
                val sinA = sin(comp.angleRad)
                val shift = comp.majorRadius * 0.42f
                val subRx = (comp.majorRadius * 0.54f).coerceIn(0.06f, 0.38f)
                val subRy = (comp.minorRadius * 0.92f).coerceIn(0.06f, 0.38f)

                strokes.add(
                    createEllipseStroke(
                        cx = (comp.centroidX - cosA * shift).coerceIn(0.12f, 0.88f),
                        cy = (comp.centroidY - sinA * shift).coerceIn(0.12f, 0.88f),
                        rx = subRx,
                        ry = subRy,
                        angleRad = comp.angleRad
                    )
                )
                strokes.add(
                    createEllipseStroke(
                        cx = (comp.centroidX + cosA * shift).coerceIn(0.12f, 0.88f),
                        cy = (comp.centroidY + sinA * shift).coerceIn(0.12f, 0.88f),
                        rx = subRx * 0.88f,
                        ry = subRy * 0.88f,
                        angleRad = comp.angleRad
                    )
                )
            } else {
                strokes.add(
                    createEllipseStroke(
                        cx = comp.centroidX.coerceIn(0.12f, 0.88f),
                        cy = comp.centroidY.coerceIn(0.12f, 0.88f),
                        rx = comp.majorRadius.coerceIn(0.07f, 0.44f),
                        ry = comp.minorRadius.coerceIn(0.07f, 0.44f),
                        angleRad = comp.angleRad
                    )
                )
            }

            // Principal symmetry / alignment axis line
            val axisLen = comp.majorRadius * 1.05f
            val dx = cos(comp.angleRad) * axisLen
            val dy = sin(comp.angleRad) * axisLen
            strokes.add(
                DrawingStroke(
                    points = listOf(
                        StrokePoint(
                            (comp.centroidX - dx).coerceIn(0.03f, 0.97f),
                            (comp.centroidY - dy).coerceIn(0.03f, 0.97f)
                        ),
                        StrokePoint(
                            (comp.centroidX + dx).coerceIn(0.03f, 0.97f),
                            (comp.centroidY + dy).coerceIn(0.03f, 0.97f)
                        )
                    ),
                    style = StrokeStyle.CONSTRUCTION,
                    strokeWidth = 1.4f,
                    alpha = 0.55f
                )
            )
        }

        return strokes
    }

    private fun createEllipseStroke(
        cx: Float,
        cy: Float,
        rx: Float,
        ry: Float,
        angleRad: Float,
        segments: Int = 36
    ): DrawingStroke {
        val cosA = cos(angleRad)
        val sinA = sin(angleRad)
        val pts = ArrayList<StrokePoint>(segments + 1)
        for (i in 0..segments) {
            val t = (i.toFloat() / segments.toFloat()) * (2.0 * PI)
            val lx = rx * cos(t).toFloat()
            val ly = ry * sin(t).toFloat()
            val gx = (cx + lx * cosA - ly * sinA).coerceIn(0.02f, 0.98f)
            val gy = (cy + lx * sinA + ly * cosA).coerceIn(0.02f, 0.98f)
            pts.add(StrokePoint(gx, gy))
        }
        return DrawingStroke(
            points = pts,
            style = StrokeStyle.CONSTRUCTION,
            strokeWidth = 1.6f,
            alpha = 0.62f,
            isClosed = true
        )
    }

    fun traceContours(
        edgeMap: BooleanArray,
        w: Int,
        h: Int,
        sobelMag: FloatArray,
        foregroundMask: BooleanArray,
        excludedMask: BooleanArray? = null,
        minLengthPx: Float,
        rdpEpsilonPx: Float
    ): List<TracedPolyline> {
        val visited = BooleanArray(w * h)
        if (excludedMask != null) {
            for (i in visited.indices) {
                if (excludedMask[i]) visited[i] = true
            }
        }

        val polylines = ArrayList<TracedPolyline>()

        // Prefer starting at endpoints (degree == 1) first for cleaner full strokes
        val startCandidates = ArrayList<Int>()
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val idx = y * w + x
                if (edgeMap[idx] && !visited[idx]) {
                    var deg = 0
                    for ((dx, dy) in neighborOffsets) {
                        if (edgeMap[(y + dy) * w + (x + dx)]) deg++
                    }
                    if (deg == 1) startCandidates.add(idx)
                }
            }
        }
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val idx = y * w + x
                if (edgeMap[idx] && !visited[idx]) {
                    startCandidates.add(idx)
                }
            }
        }

        for (startIdx in startCandidates) {
            if (visited[startIdx]) continue
            val chain = traceSingleSmoothChain(startIdx, edgeMap, visited, w, h)
            if (chain.size < 4) continue

            val lengthPx = computeChainLength(chain, w)
            if (lengthPx < minLengthPx) continue

            var gradSum = 0f
            var fgHits = 0
            for (idx in chain) {
                gradSum += sobelMag[idx]
                if (foregroundMask[idx]) fgHits++
            }
            val avgGrad = gradSum / chain.size.toFloat()
            val fgFraction = fgHits.toFloat() / chain.size.toFloat()

            val rawPts = chain.map { idx ->
                Pair((idx % w).toFloat(), (idx / w).toFloat())
            }
            val smoothed = smoothPoints(rawPts)
            val simplified = rdpSimplify(smoothed, rdpEpsilonPx)
            if (simplified.size < 2) continue

            val normPts = simplified.map { (px, py) ->
                StrokePoint(
                    x = (px / w.toFloat()).coerceIn(0.005f, 0.995f),
                    y = (py / h.toFloat()).coerceIn(0.005f, 0.995f)
                )
            }

            val saliency = lengthPx * (1f + avgGrad * 0.04f) * (0.65f + 0.7f * fgFraction)
            polylines.add(
                TracedPolyline(
                    points = normPts,
                    saliencyScore = saliency,
                    lengthPx = lengthPx,
                    foregroundFraction = fgFraction
                )
            )
        }

        return polylines.sortedByDescending { it.saliencyScore }
    }

    private fun traceSingleSmoothChain(
        startIdx: Int,
        edgeMap: BooleanArray,
        visited: BooleanArray,
        w: Int,
        h: Int
    ): List<Int> {
        val chain = ArrayList<Int>(64)
        var curr = startIdx
        visited[curr] = true
        chain.add(curr)

        var prevDx = 0f
        var prevDy = 0f
        var hasDir = false

        while (true) {
            val cx = curr % w
            val cy = curr / w
            var bestNext = -1
            var bestScore = Float.NEGATIVE_INFINITY

            for ((dx, dy) in neighborOffsets) {
                val nx = cx + dx
                val ny = cy + dy
                if (nx !in 1 until w - 1 || ny !in 1 until h - 1) continue
                val nIdx = ny * w + nx
                if (!edgeMap[nIdx] || visited[nIdx]) continue

                val dist = if (dx != 0 && dy != 0) 1.414f else 1f
                val stepDx = dx / dist
                val stepDy = dy / dist
                val alignScore = if (hasDir) (stepDx * prevDx + stepDy * prevDy) else 0f
                val cardinalBonus = if (dx == 0 || dy == 0) 0.1f else 0f
                val score = alignScore + cardinalBonus
                if (score > bestScore) {
                    bestScore = score
                    bestNext = nIdx
                }
            }

            if (bestNext == -1) break
            val nx = bestNext % w
            val ny = bestNext / w
            val stepDx = (nx - cx).toFloat()
            val stepDy = (ny - cy).toFloat()
            val len = hypot(stepDx, stepDy).coerceAtLeast(1f)
            prevDx = stepDx / len
            prevDy = stepDy / len
            hasDir = true

            visited[bestNext] = true
            chain.add(bestNext)
            curr = bestNext
        }

        return chain
    }

    fun markDrawnExclusionMask(
        polylines: List<TracedPolyline>,
        w: Int,
        h: Int,
        radiusPx: Int = 2
    ): BooleanArray {
        val mask = BooleanArray(w * h)
        for (poly in polylines) {
            for (i in 0 until poly.points.lastIndex) {
                val p0 = poly.points[i]
                val p1 = poly.points[i + 1]
                val x0 = p0.x * w
                val y0 = p0.y * h
                val x1 = p1.x * w
                val y1 = p1.y * h
                val steps = max(1, ceil(hypot(x1 - x0, y1 - y0)).toInt())
                for (s in 0..steps) {
                    val t = s.toFloat() / steps.toFloat()
                    val px = (x0 + (x1 - x0) * t).roundToInt()
                    val py = (y0 + (y1 - y0) * t).roundToInt()
                    for (dy in -radiusPx..radiusPx) {
                        val ny = py + dy
                        if (ny !in 0 until h) continue
                        for (dx in -radiusPx..radiusPx) {
                            val nx = px + dx
                            if (nx in 0 until w) {
                                mask[ny * w + nx] = true
                            }
                        }
                    }
                }
            }
        }
        return mask
    }

    fun generateShadingStrokes(
        lum: FloatArray,
        w: Int,
        h: Int,
        foregroundMask: BooleanArray,
        hasSalientForeground: Boolean
    ): List<DrawingStroke> {
        val smoothLum = ImageProcessingUtils.gaussianBlur(lum, w, h, sigma = 3.2f)
        val shadingStrokes = ArrayList<DrawingStroke>()

        // Layer 1: Mid-tone diagonal pencil hatching (45 deg)
        val midSpacing = max(7, min(w, h) / 36)
        shadingStrokes.addAll(
            scanDiagonalHatch(
                smoothLum = smoothLum,
                w = w,
                h = h,
                foregroundMask = foregroundMask,
                requireForeground = hasSalientForeground,
                lumThreshold = 132f,
                spacing = midSpacing,
                positiveSlope = true,
                strokeWidth = 1.15f,
                alpha = 0.34f
            )
        )

        // Layer 2: Deep shadow cross-hatching (-45 deg)
        val deepSpacing = max(5, min(w, h) / 46)
        shadingStrokes.addAll(
            scanDiagonalHatch(
                smoothLum = smoothLum,
                w = w,
                h = h,
                foregroundMask = foregroundMask,
                requireForeground = hasSalientForeground,
                lumThreshold = 74f,
                spacing = deepSpacing,
                positiveSlope = false,
                strokeWidth = 1.25f,
                alpha = 0.45f
            )
        )

        return shadingStrokes
    }

    private fun scanDiagonalHatch(
        smoothLum: FloatArray,
        w: Int,
        h: Int,
        foregroundMask: BooleanArray,
        requireForeground: Boolean,
        lumThreshold: Float,
        spacing: Int,
        positiveSlope: Boolean,
        strokeWidth: Float,
        alpha: Float
    ): List<DrawingStroke> {
        val strokes = ArrayList<DrawingStroke>()
        val minRunPx = max(6, min(w, h) / 35)
        val maxDiag = w + h

        var d = -h
        while (d < maxDiag) {
            var runStartX = -1
            var runStartY = -1
            var runLen = 0
            var lastX = -1
            var lastY = -1

            for (x in 0 until w) {
                val y = if (positiveSlope) d - x else x - d
                if (y !in 0 until h) {
                    if (runLen >= minRunPx) {
                        strokes.add(buildHatchStroke(runStartX, runStartY, lastX, lastY, w, h, strokeWidth, alpha))
                    }
                    runLen = 0
                    continue
                }

                val idx = y * w + x
                val inSubject = !requireForeground || foregroundMask[idx]
                val isShadow = smoothLum[idx] < lumThreshold && inSubject

                if (isShadow) {
                    if (runLen == 0) {
                        runStartX = x
                        runStartY = y
                    }
                    lastX = x
                    lastY = y
                    runLen++
                } else {
                    if (runLen >= minRunPx) {
                        strokes.add(buildHatchStroke(runStartX, runStartY, lastX, lastY, w, h, strokeWidth, alpha))
                    }
                    runLen = 0
                }
            }

            if (runLen >= minRunPx) {
                strokes.add(buildHatchStroke(runStartX, runStartY, lastX, lastY, w, h, strokeWidth, alpha))
            }
            d += spacing
        }

        return strokes
    }

    private fun buildHatchStroke(
        x0: Int,
        y0: Int,
        x1: Int,
        y1: Int,
        w: Int,
        h: Int,
        strokeWidth: Float,
        alpha: Float
    ): DrawingStroke {
        val mx = (x0 + x1) * 0.5f / w.toFloat()
        val my = (y0 + y1) * 0.5f / h.toFloat()
        return DrawingStroke(
            points = listOf(
                StrokePoint((x0.toFloat() / w).coerceIn(0.01f, 0.99f), (y0.toFloat() / h).coerceIn(0.01f, 0.99f)),
                StrokePoint(mx.coerceIn(0.01f, 0.99f), my.coerceIn(0.01f, 0.99f)),
                StrokePoint((x1.toFloat() / w).coerceIn(0.01f, 0.99f), (y1.toFloat() / h).coerceIn(0.01f, 0.99f))
            ),
            style = StrokeStyle.SHADING,
            strokeWidth = strokeWidth,
            alpha = alpha
        )
    }

    private fun computeChainLength(chain: List<Int>, w: Int): Float {
        var total = 0f
        for (i in 0 until chain.lastIndex) {
            val a = chain[i]
            val b = chain[i + 1]
            val dx = ((b % w) - (a % w)).toFloat()
            val dy = ((b / w) - (a / w)).toFloat()
            total += hypot(dx, dy)
        }
        return total
    }

    private fun smoothPoints(pts: List<Pair<Float, Float>>): List<Pair<Float, Float>> {
        if (pts.size < 3) return pts
        val out = ArrayList<Pair<Float, Float>>(pts.size)
        out.add(pts.first())
        for (i in 1 until pts.lastIndex) {
            val x = 0.25f * pts[i - 1].first + 0.5f * pts[i].first + 0.25f * pts[i + 1].first
            val y = 0.25f * pts[i - 1].second + 0.5f * pts[i].second + 0.25f * pts[i + 1].second
            out.add(x to y)
        }
        out.add(pts.last())
        return out
    }

    fun rdpSimplify(points: List<Pair<Float, Float>>, epsilon: Float): List<Pair<Float, Float>> {
        if (points.size < 3) return points
        val keep = BooleanArray(points.size)
        keep[0] = true
        keep[points.lastIndex] = true

        val stack = ArrayDeque<Pair<Int, Int>>()
        stack.addLast(0 to points.lastIndex)

        while (stack.isNotEmpty()) {
            val (startIdx, endIdx) = stack.removeLast()
            if (endIdx - startIdx < 2) continue

            var maxDist = 0f
            var splitIdx = -1
            val a = points[startIdx]
            val b = points[endIdx]

            for (i in (startIdx + 1) until endIdx) {
                val d = pointToSegmentDistance(points[i], a, b)
                if (d > maxDist) {
                    maxDist = d
                    splitIdx = i
                }
            }

            if (splitIdx != -1 && maxDist > epsilon) {
                keep[splitIdx] = true
                stack.addLast(startIdx to splitIdx)
                stack.addLast(splitIdx to endIdx)
            }
        }

        val result = ArrayList<Pair<Float, Float>>(points.size)
        for (i in points.indices) {
            if (keep[i]) result.add(points[i])
        }
        return result
    }

    private fun pointToSegmentDistance(
        p: Pair<Float, Float>,
        a: Pair<Float, Float>,
        b: Pair<Float, Float>
    ): Float {
        val dx = b.first - a.first
        val dy = b.second - a.second
        val lenSq = dx * dx + dy * dy
        if (lenSq < 1e-6f) return hypot(p.first - a.first, p.second - a.second)
        val t = (((p.first - a.first) * dx + (p.second - a.second) * dy) / lenSq).coerceIn(0f, 1f)
        val projX = a.first + t * dx
        val projY = a.second + t * dy
        return hypot(p.first - projX, p.second - projY)
    }
}
