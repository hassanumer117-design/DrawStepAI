package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.data.DrawingRepository
import com.example.data.local.DrawStepDatabase
import com.example.ui.navigation.DrawStepNavHost
import com.example.ui.theme.DrawStepTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = DrawStepDatabase.getInstance(applicationContext)
        val repository = DrawingRepository(database.drawingTutorialDao())

        setContent {
            DrawStepTheme {
                DrawStepNavHost(repository = repository)
            }
        }
    }
}
