package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [DrawingTutorialEntity::class],
    version = 1,
    exportSchema = false
)
abstract class DrawStepDatabase : RoomDatabase() {
    abstract fun drawingTutorialDao(): DrawingTutorialDao

    companion object {
        @Volatile
        private var INSTANCE: DrawStepDatabase? = null

        fun getInstance(context: Context): DrawStepDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    DrawStepDatabase::class.java,
                    "drawstep_ai_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
