package com.example.ui.tutorial

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.domain.model.DrawingTutorial
import com.example.ui.components.AnimatedDrawingCanvas

@Composable
fun TutorialScreen(
    viewModel: TutorialViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val state = uiState) {
                TutorialUiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    }
                }
                TutorialUiState.NotFound -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = stringResource(R.string.error_tutorial_not_found),
                            style = MaterialTheme.typography.titleMedium,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onNavigateBack,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Text(stringResource(R.string.btn_back))
                        }
                    }
                }
                is TutorialUiState.Ready -> {
                    TutorialContent(
                        tutorial = state.tutorial,
                        onNavigateBack = onNavigateBack,
                        onPrevious = viewModel::goToPreviousStep,
                        onNext = { viewModel.goToNextStep(onNavigateBack) }
                    )
                }
            }
        }
    }
}

@Composable
private fun TutorialContent(
    tutorial: DrawingTutorial,
    onNavigateBack: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit
) {
    val stepIndex = tutorial.currentStepIndex.coerceIn(0, (tutorial.steps.size - 1).coerceAtLeast(0))
    val currentStep = tutorial.steps[stepIndex]
    val totalSteps = tutorial.totalSteps.coerceAtLeast(1)
    val isFirstStep = stepIndex == 0
    val isLastStep = stepIndex == totalSteps - 1

    var replayNonce by remember { mutableIntStateOf(0) }
    val animProgress = remember { Animatable(0f) }

    LaunchedEffect(stepIndex, replayNonce) {
        animProgress.snapTo(0f)
        val durationMs = (850 + currentStep.strokes.size * 70).coerceIn(900, 1900)
        animProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(
                durationMillis = durationMs,
                easing = FastOutSlowInEasing
            )
        )
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideLayout = maxWidth >= 680.dp && maxWidth > maxHeight

        if (isWideLayout) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AnimatedDrawingCanvas(
                    steps = tutorial.steps,
                    currentStepIndex = stepIndex,
                    stepAnimationProgress = animProgress.value,
                    aspectRatio = tutorial.aspectRatio,
                    contentDescriptionText = stringResource(R.string.cd_drawing_canvas),
                    modifier = Modifier
                        .weight(1.2f)
                        .fillMaxHeight()
                )

                Column(
                    modifier = Modifier
                        .weight(0.8f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    TutorialTopHeader(
                        stepNumber = stepIndex + 1,
                        totalSteps = totalSteps,
                        stageName = currentStep.stage.displayName,
                        onBack = onNavigateBack
                    )

                    InstructionCard(instruction = currentStep.instruction)

                    TutorialControls(
                        isFirstStep = isFirstStep,
                        isLastStep = isLastStep,
                        onPrevious = onPrevious,
                        onReplay = { replayNonce++ },
                        onNext = onNext
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TutorialTopHeader(
                    stepNumber = stepIndex + 1,
                    totalSteps = totalSteps,
                    stageName = currentStep.stage.displayName,
                    onBack = onNavigateBack
                )

                AnimatedDrawingCanvas(
                    steps = tutorial.steps,
                    currentStepIndex = stepIndex,
                    stepAnimationProgress = animProgress.value,
                    aspectRatio = tutorial.aspectRatio,
                    contentDescriptionText = stringResource(R.string.cd_drawing_canvas),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )

                InstructionCard(instruction = currentStep.instruction)

                TutorialControls(
                    isFirstStep = isFirstStep,
                    isLastStep = isLastStep,
                    onPrevious = onPrevious,
                    onReplay = { replayNonce++ },
                    onNext = onNext
                )
            }
        }
    }
}

@Composable
private fun TutorialTopHeader(
    stepNumber: Int,
    totalSteps: Int,
    stageName: String,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.btn_back),
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }

            Text(
                text = stringResource(R.string.step_counter_format, stepNumber, totalSteps),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.testTag("step_counter")
            )

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Text(
                    text = stageName,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        LinearProgressIndicator(
            progress = { stepNumber.toFloat() / totalSteps.toFloat() },
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
        )
    }
}

@Composable
private fun InstructionCard(instruction: String) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = instruction,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 14.dp)
                .testTag("step_instruction")
        )
    }
}

@Composable
private fun TutorialControls(
    isFirstStep: Boolean,
    isLastStep: Boolean,
    onPrevious: () -> Unit,
    onReplay: () -> Unit,
    onNext: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedButton(
            onClick = onPrevious,
            enabled = !isFirstStep,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
            modifier = Modifier
                .weight(1f)
                .minimumInteractiveComponentSize()
                .testTag("previous_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = stringResource(R.string.btn_previous),
                maxLines = 1
            )
        }

        FilledTonalButton(
            onClick = onReplay,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
            modifier = Modifier
                .weight(0.9f)
                .minimumInteractiveComponentSize()
                .testTag("replay_button")
        ) {
            Icon(
                imageVector = Icons.Rounded.Replay,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = stringResource(R.string.btn_replay),
                maxLines = 1
            )
        }

        Button(
            onClick = onNext,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
            modifier = Modifier
                .weight(1f)
                .minimumInteractiveComponentSize()
                .testTag("next_button")
        ) {
            Text(
                text = stringResource(if (isLastStep) R.string.btn_finish else R.string.btn_next),
                maxLines = 1
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
                imageVector = if (isLastStep) Icons.Rounded.Check else Icons.AutoMirrored.Rounded.ArrowForward,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
