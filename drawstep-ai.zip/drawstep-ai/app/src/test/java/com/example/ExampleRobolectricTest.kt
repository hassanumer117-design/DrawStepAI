package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.DrawingRepository
import com.example.data.local.DrawStepDatabase
import com.example.domain.model.DrawingStep
import com.example.domain.model.DrawingStroke
import com.example.domain.model.DrawingTutorial
import com.example.domain.model.StrokePoint
import com.example.domain.model.StrokeStyle
import com.example.domain.model.TutorialStage
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.theme.DrawStepTheme
import com.example.ui.tutorial.TutorialScreen
import com.example.ui.tutorial.TutorialViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var database: DrawStepDatabase
    private lateinit var repository: DrawingRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, DrawStepDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = DrawingRepository(database.drawingTutorialDao())
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `app name matches DrawStep AI`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("DrawStep AI", context.getString(R.string.app_name))
    }

    @Test
    fun `room persistence saves updates and deletes tutorials`() = runBlocking {
        val sample = createSampleTutorial(id = "t1", title = "Flower Study")
        repository.saveTutorial(sample)

        val all = repository.observeAllTutorials().first()
        assertEquals(1, all.size)
        assertEquals("Flower Study", all.first().title)
        assertFalse(all.first().isCompleted)

        // Advance to final step -> marks completed
        repository.updateStepProgress(id = "t1", stepIndex = 9, totalSteps = 10)
        val updated = repository.observeTutorial("t1").first()!!
        assertEquals(9, updated.currentStepIndex)
        assertTrue(updated.isCompleted)

        repository.deleteTutorial("t1")
        val afterDelete = repository.observeAllTutorials().first()
        assertTrue(afterDelete.isEmpty())
    }

    @Test
    fun `home screen renders logo upload button and saved drawings with delete`() {
        runBlocking {
            repository.saveTutorial(createSampleTutorial(id = "saved_1", title = "Cat Sketch"))
        }
        val homeViewModel = HomeViewModel(repository)

        composeRule.setContent {
            DrawStepTheme {
                HomeScreen(
                    viewModel = homeViewModel,
                    onOpenTutorial = {}
                )
            }
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("app_title").assertIsDisplayed()
        composeRule.onNodeWithTag("upload_image_button").assertIsDisplayed()
        composeRule.onNodeWithTag("my_drawings_header").assertIsDisplayed()
        composeRule.onNodeWithText("Cat Sketch").assertIsDisplayed()

        composeRule.onNodeWithTag("delete_button_saved_1").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("confirm_delete_button").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("empty_drawings_card").assertIsDisplayed()
    }

    @Test
    fun `tutorial screen steps forward backward and replays`() {
        runBlocking {
            repository.saveTutorial(createSampleTutorial(id = "tut_1", title = "Car Study"))
        }
        val tutorialViewModel = TutorialViewModel("tut_1", repository)

        composeRule.setContent {
            DrawStepTheme {
                TutorialScreen(
                    viewModel = tutorialViewModel,
                    onNavigateBack = {}
                )
            }
        }
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithTag("drawing_canvas").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("drawing_canvas").assertIsDisplayed()
        composeRule.onNodeWithText("Step 1 of 10").assertIsDisplayed()
        composeRule.onNodeWithTag("previous_button").assertIsNotEnabled()
        composeRule.onNodeWithTag("replay_button").assertIsEnabled()

        composeRule.onNodeWithTag("next_button").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithText("Step 2 of 10").assertIsDisplayed()
        composeRule.onNodeWithTag("previous_button").assertIsEnabled()

        composeRule.onNodeWithTag("replay_button").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("previous_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Step 1 of 10").assertIsDisplayed()
    }

    @Test
    fun `createTutorialFromUri decodes real JPEG and transparent PNG URIs`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()

        // 1. Test large JPEG photo URI
        val jpegFile = File(context.cacheDir, "sample_photo.jpg")
        val bmpJpg = Bitmap.createBitmap(800, 600, Bitmap.Config.ARGB_8888)
        val canvasJpg = Canvas(bmpJpg)
        canvasJpg.drawColor(Color.rgb(240, 235, 228))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(45, 55, 70)
            style = Paint.Style.FILL
        }
        canvasJpg.drawCircle(400f, 280f, 160f, paint)
        paint.color = Color.rgb(180, 90, 60)
        canvasJpg.drawRect(260f, 430f, 540f, 550f, paint)
        FileOutputStream(jpegFile).use { out -> bmpJpg.compress(Bitmap.CompressFormat.JPEG, 92, out) }
        bmpJpg.recycle()

        val jpegResult = repository.createTutorialFromUri(context, Uri.fromFile(jpegFile)) {}
        assertTrue("JPEG URI processing failed: ${jpegResult.exceptionOrNull()}", jpegResult.isSuccess)
        val jpegTutorial = jpegResult.getOrThrow()
        assertTrue(jpegTutorial.steps.size in 10..50)

        // 2. Test transparent PNG URI
        val pngFile = File(context.cacheDir, "transparent_flower.png")
        val bmpPng = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888)
        val canvasPng = Canvas(bmpPng)
        canvasPng.drawColor(Color.TRANSPARENT)
        paint.color = Color.rgb(30, 80, 120)
        canvasPng.drawCircle(200f, 200f, 120f, paint)
        FileOutputStream(pngFile).use { out -> bmpPng.compress(Bitmap.CompressFormat.PNG, 100, out) }
        bmpPng.recycle()

        val pngResult = repository.createTutorialFromUri(context, Uri.fromFile(pngFile)) {}
        assertTrue("PNG URI processing failed: ${pngResult.exceptionOrNull()}", pngResult.isSuccess)
        val pngTutorial = pngResult.getOrThrow()
        assertTrue(pngTutorial.steps.size in 10..50)
    }

    private fun createSampleTutorial(id: String, title: String): DrawingTutorial {
        val steps = (1..10).map { num ->
            DrawingStep(
                stepNumber = num,
                stage = when (num) {
                    1 -> TutorialStage.BASIC_SHAPES
                    in 2..4 -> TutorialStage.MAIN_OUTLINE
                    in 5..7 -> TutorialStage.INTERNAL_DETAILS
                    in 8..9 -> TutorialStage.SHADING
                    else -> TutorialStage.FINAL_TOUCH
                },
                instruction = "Instruction for step $num",
                strokes = listOf(
                    DrawingStroke(
                        points = listOf(
                            StrokePoint(0.2f, 0.2f + num * 0.05f),
                            StrokePoint(0.8f, 0.2f + num * 0.05f)
                        ),
                        style = if (num == 1) StrokeStyle.CONSTRUCTION else StrokeStyle.OUTLINE
                    )
                )
            )
        }
        return DrawingTutorial(
            id = id,
            title = title,
            aspectRatio = 1.0f,
            steps = steps,
            currentStepIndex = 0,
            isCompleted = false,
            createdAt = 1000L,
            updatedAt = 1000L
        )
    }
}
