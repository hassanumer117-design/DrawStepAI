package com.example

import com.example.domain.model.TutorialStage
import com.example.engine.DrawingTutorialGenerator
import com.example.engine.PixelBuffer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

class DrawingEngineTest {

    @Test
    fun `portrait image generates 10 to 50 progressive steps with all stages`() {
        val buffer = createPortraitTestImage(320, 400)
        val tutorial = DrawingTutorialGenerator.generateFromPixels("Portrait Study", buffer)
        assertValidProgressiveTutorial("Portrait", tutorial)
    }

    @Test
    fun `animal image generates 10 to 50 progressive steps with real strokes`() {
        val buffer = createAnimalTestImage(360, 280)
        val tutorial = DrawingTutorialGenerator.generateFromPixels("Cat Sketch", buffer)
        assertValidProgressiveTutorial("Animal", tutorial)
    }

    @Test
    fun `car image generates 10 to 50 progressive steps with real strokes`() {
        val buffer = createCarTestImage(400, 260)
        val tutorial = DrawingTutorialGenerator.generateFromPixels("Car Study", buffer)
        assertValidProgressiveTutorial("Car", tutorial)
    }

    @Test
    fun `building image generates 10 to 50 progressive steps with real strokes`() {
        val buffer = createBuildingTestImage(340, 340)
        val tutorial = DrawingTutorialGenerator.generateFromPixels("Building Sketch", buffer)
        assertValidProgressiveTutorial("Building", tutorial)
    }

    @Test
    fun `flower image generates 10 to 50 progressive steps with real strokes`() {
        val buffer = createFlowerTestImage(300, 360)
        val tutorial = DrawingTutorialGenerator.generateFromPixels("Flower Study", buffer)
        assertValidProgressiveTutorial("Flower", tutorial)
    }

    @Test
    fun `everyday object mug image generates 10 to 50 progressive steps with real strokes`() {
        val buffer = createMugTestImage(320, 320)
        val tutorial = DrawingTutorialGenerator.generateFromPixels("Coffee Mug", buffer)
        assertValidProgressiveTutorial("Everyday Object", tutorial)
    }

    private fun assertValidProgressiveTutorial(
        label: String,
        tutorial: com.example.domain.model.DrawingTutorial
    ) {
        val steps = tutorial.steps
        assertTrue(
            "$label step count ${steps.size} must be in 10..50",
            steps.size in 10..50
        )
        assertEquals(TutorialStage.BASIC_SHAPES, steps.first().stage)
        assertEquals(TutorialStage.FINAL_TOUCH, steps.last().stage)

        val hasOutlines = steps.any { it.stage == TutorialStage.MAIN_OUTLINE }
        assertTrue("$label must include MAIN_OUTLINE stage", hasOutlines)

        steps.forEachIndexed { idx, step ->
            assertEquals(idx + 1, step.stepNumber)
            assertTrue("$label step ${step.stepNumber} instruction blank", step.instruction.isNotBlank())
            assertTrue("$label step ${step.stepNumber} has no strokes", step.strokes.isNotEmpty())
            step.strokes.forEach { stroke ->
                assertTrue(stroke.points.size >= 2)
                stroke.points.forEach { pt ->
                    assertTrue("x out of bounds: ${pt.x}", pt.x in 0f..1f)
                    assertTrue("y out of bounds: ${pt.y}", pt.y in 0f..1f)
                }
            }
        }
    }

    private fun blankCanvas(w: Int, h: Int, bg: Int = rgb(242, 239, 233)): IntArray {
        return IntArray(w * h) { bg }
    }

    private fun rgb(r: Int, g: Int, b: Int): Int {
        return (0xFF shl 24) or ((r and 0xFF) shl 16) or ((g and 0xFF) shl 8) or (b and 0xFF)
    }

    private fun fillEllipse(
        argb: IntArray,
        w: Int,
        h: Int,
        cx: Float,
        cy: Float,
        rx: Float,
        ry: Float,
        color: Int
    ) {
        for (y in 0 until h) {
            for (x in 0 until w) {
                val dx = (x - cx) / rx
                val dy = (y - cy) / ry
                if (dx * dx + dy * dy <= 1f) {
                    argb[y * w + x] = color
                }
            }
        }
    }

    private fun fillRect(
        argb: IntArray,
        w: Int,
        h: Int,
        x0: Int,
        y0: Int,
        x1: Int,
        y1: Int,
        color: Int
    ) {
        for (y in y0.coerceIn(0, h - 1)..y1.coerceIn(0, h - 1)) {
            for (x in x0.coerceIn(0, w - 1)..x1.coerceIn(0, w - 1)) {
                argb[y * w + x] = color
            }
        }
    }

    private fun drawLine(
        argb: IntArray,
        w: Int,
        h: Int,
        x0: Float,
        y0: Float,
        x1: Float,
        y1: Float,
        thickness: Int,
        color: Int
    ) {
        val steps = hypot(x1 - x0, y1 - y0).toInt().coerceAtLeast(1) * 2
        for (i in 0..steps) {
            val t = i.toFloat() / steps
            val px = (x0 + (x1 - x0) * t).toInt()
            val py = (y0 + (y1 - y0) * t).toInt()
            for (dy in -thickness..thickness) {
                for (dx in -thickness..thickness) {
                    val nx = px + dx
                    val ny = py + dy
                    if (nx in 0 until w && ny in 0 until h) {
                        argb[ny * w + nx] = color
                    }
                }
            }
        }
    }

    private fun createPortraitTestImage(w: Int, h: Int): PixelBuffer {
        val px = blankCanvas(w, h, rgb(235, 232, 228))
        // Shoulders
        fillEllipse(px, w, h, w * 0.5f, h * 0.88f, w * 0.34f, h * 0.22f, rgb(55, 65, 85))
        // Hair backdrop
        fillEllipse(px, w, h, w * 0.5f, h * 0.36f, w * 0.24f, h * 0.26f, rgb(42, 34, 30))
        // Face oval
        fillEllipse(px, w, h, w * 0.5f, h * 0.42f, w * 0.19f, h * 0.23f, rgb(212, 172, 145))
        // Left side shading on face
        fillEllipse(px, w, h, w * 0.39f, h * 0.44f, w * 0.06f, h * 0.16f, rgb(165, 128, 104))
        // Eyes
        fillEllipse(px, w, h, w * 0.43f, h * 0.39f, w * 0.032f, w * 0.02f, rgb(32, 28, 25))
        fillEllipse(px, w, h, w * 0.57f, h * 0.39f, w * 0.032f, w * 0.02f, rgb(32, 28, 25))
        // Nose & mouth
        drawLine(px, w, h, w * 0.5f, h * 0.40f, w * 0.49f, h * 0.49f, 2, rgb(130, 92, 74))
        drawLine(px, w, h, w * 0.44f, h * 0.54f, w * 0.56f, h * 0.54f, 2, rgb(150, 72, 68))
        return PixelBuffer(w, h, px)
    }

    private fun createAnimalTestImage(w: Int, h: Int): PixelBuffer {
        val px = blankCanvas(w, h, rgb(238, 242, 232))
        // Cat body & tail
        fillEllipse(px, w, h, w * 0.56f, h * 0.62f, w * 0.22f, h * 0.16f, rgb(88, 78, 72))
        drawLine(px, w, h, w * 0.76f, h * 0.62f, w * 0.90f, h * 0.42f, 6, rgb(70, 62, 58))
        // Head & ears
        fillEllipse(px, w, h, w * 0.32f, h * 0.46f, w * 0.14f, h * 0.14f, rgb(98, 88, 82))
        drawLine(px, w, h, w * 0.22f, h * 0.36f, w * 0.25f, h * 0.22f, 6, rgb(72, 62, 58))
        drawLine(px, w, h, w * 0.40f, h * 0.36f, w * 0.38f, h * 0.22f, 6, rgb(72, 62, 58))
        // Eyes & whiskers
        fillEllipse(px, w, h, w * 0.27f, h * 0.44f, 8f, 8f, rgb(24, 24, 24))
        fillEllipse(px, w, h, w * 0.36f, h * 0.44f, 8f, 8f, rgb(24, 24, 24))
        // Legs
        fillRect(px, w, h, (w * 0.42f).toInt(), (h * 0.72f).toInt(), (w * 0.46f).toInt(), (h * 0.88f).toInt(), rgb(68, 60, 56))
        fillRect(px, w, h, (w * 0.64f).toInt(), (h * 0.72f).toInt(), (w * 0.68f).toInt(), (h * 0.88f).toInt(), rgb(68, 60, 56))
        return PixelBuffer(w, h, px)
    }

    private fun createCarTestImage(w: Int, h: Int): PixelBuffer {
        val px = blankCanvas(w, h, rgb(235, 240, 245))
        // Chassis & cabin
        fillRect(px, w, h, (w * 0.14f).toInt(), (h * 0.50f).toInt(), (w * 0.86f).toInt(), (h * 0.70f).toInt(), rgb(185, 58, 45))
        fillRect(px, w, h, (w * 0.28f).toInt(), (h * 0.34f).toInt(), (w * 0.70f).toInt(), (h * 0.51f).toInt(), rgb(170, 50, 40))
        // Windows
        fillRect(px, w, h, (w * 0.31f).toInt(), (h * 0.37f).toInt(), (w * 0.48f).toInt(), (h * 0.49f).toInt(), rgb(70, 95, 120))
        fillRect(px, w, h, (w * 0.51f).toInt(), (h * 0.37f).toInt(), (w * 0.67f).toInt(), (h * 0.49f).toInt(), rgb(70, 95, 120))
        // Wheels
        fillEllipse(px, w, h, w * 0.28f, h * 0.72f, w * 0.085f, w * 0.085f, rgb(28, 28, 30))
        fillEllipse(px, w, h, w * 0.28f, h * 0.72f, w * 0.045f, w * 0.045f, rgb(180, 185, 190))
        fillEllipse(px, w, h, w * 0.72f, h * 0.72f, w * 0.085f, w * 0.085f, rgb(28, 28, 30))
        fillEllipse(px, w, h, w * 0.72f, h * 0.72f, w * 0.045f, w * 0.045f, rgb(180, 185, 190))
        return PixelBuffer(w, h, px)
    }

    private fun createBuildingTestImage(w: Int, h: Int): PixelBuffer {
        val px = blankCanvas(w, h, rgb(225, 236, 246))
        // Main facade
        fillRect(px, w, h, (w * 0.22f).toInt(), (h * 0.32f).toInt(), (w * 0.78f).toInt(), (h * 0.88f).toInt(), rgb(195, 175, 152))
        // Roof triangle
        for (y in (h * 0.12f).toInt()..(h * 0.32f).toInt()) {
            val t = (y - h * 0.12f) / (h * 0.20f)
            val halfW = (w * 0.32f) * t
            for (x in (w * 0.5f - halfW).toInt()..(w * 0.5f + halfW).toInt()) {
                if (x in 0 until w && y in 0 until h) px[y * w + x] = rgb(120, 56, 48)
            }
        }
        // Door & windows
        fillRect(px, w, h, (w * 0.44f).toInt(), (h * 0.66f).toInt(), (w * 0.56f).toInt(), (h * 0.88f).toInt(), rgb(72, 52, 42))
        fillRect(px, w, h, (w * 0.29f).toInt(), (h * 0.40f).toInt(), (w * 0.40f).toInt(), (h * 0.54f).toInt(), rgb(58, 76, 98))
        fillRect(px, w, h, (w * 0.60f).toInt(), (h * 0.40f).toInt(), (w * 0.71f).toInt(), (h * 0.54f).toInt(), rgb(58, 76, 98))
        return PixelBuffer(w, h, px)
    }

    private fun createFlowerTestImage(w: Int, h: Int): PixelBuffer {
        val px = blankCanvas(w, h, rgb(240, 245, 238))
        // Stem & leaves
        drawLine(px, w, h, w * 0.5f, h * 0.45f, w * 0.5f, h * 0.90f, 5, rgb(48, 112, 56))
        fillEllipse(px, w, h, w * 0.38f, h * 0.70f, w * 0.11f, h * 0.045f, rgb(64, 134, 72))
        fillEllipse(px, w, h, w * 0.62f, h * 0.64f, w * 0.11f, h * 0.045f, rgb(64, 134, 72))
        // Petals
        for (k in 0 until 8) {
            val angle = k * (2.0 * PI / 8.0)
            val pxCenter = w * 0.5f + cos(angle).toFloat() * w * 0.17f
            val pyCenter = h * 0.34f + sin(angle).toFloat() * w * 0.17f
            fillEllipse(px, w, h, pxCenter, pyCenter, w * 0.09f, w * 0.09f, rgb(214, 96, 84))
        }
        // Center disc
        fillEllipse(px, w, h, w * 0.5f, h * 0.34f, w * 0.09f, w * 0.09f, rgb(120, 78, 32))
        return PixelBuffer(w, h, px)
    }

    private fun createMugTestImage(w: Int, h: Int): PixelBuffer {
        val px = blankCanvas(w, h, rgb(245, 242, 236))
        // Mug body
        fillRect(px, w, h, (w * 0.30f).toInt(), (h * 0.34f).toInt(), (w * 0.66f).toInt(), (h * 0.78f).toInt(), rgb(72, 108, 128))
        // Rim ellipse (dark coffee inside)
        fillEllipse(px, w, h, w * 0.48f, h * 0.34f, w * 0.18f, h * 0.055f, rgb(46, 32, 24))
        // Handle loop
        for (a in -90..90 step 3) {
            val rad = a * PI / 180.0
            val hx = (w * 0.66f + cos(rad).toFloat() * w * 0.11f).toInt()
            val hy = (h * 0.56f + sin(rad).toFloat() * h * 0.13f).toInt()
            fillEllipse(px, w, h, hx.toFloat(), hy.toFloat(), 5f, 5f, rgb(58, 90, 110))
        }
        // Shadow on table
        fillEllipse(px, w, h, w * 0.46f, h * 0.80f, w * 0.22f, h * 0.04f, rgb(150, 145, 138))
        return PixelBuffer(w, h, px)
    }
}
